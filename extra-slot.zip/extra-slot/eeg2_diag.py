"""Pipeline diagnostic on NON-test seeds (59xxxx): AP with the correct count only (no extra-slot results).
(a) real background at the design SNRs, (b) real background at SNR 20, (c) white background at SNR 2."""
import numpy as np, json
import eeg2_run as H
WINV = np.linalg.inv(H.WALL); X0 = H.X.copy()
def run(snr, white, n=12):
    p15 = []; dist = []
    for i in range(n):
        seed = 591000 + i; Q = 2 + i % 3; rho = [1.0, 0.8, 0.3][i % 3]
        H.X = WINV @ np.random.default_rng(seed + 5).standard_normal(X0.shape) if white else X0
        rng = np.random.default_rng(seed)
        idx, data, eps, Tn = H.simulate(Q, rho, snr, rng)
        f = H.mo.Fit(data, eps, Tn); S = f.ap(Q)
        p15.append(H.mo.score(S, H.pos6[idx], 0.015)['precision'])
        dist.append(np.mean(np.linalg.norm(H.pos7[S][:, None] - H.pos6[idx][None], axis=2).min(1)) * 1000)
    return np.mean(p15), np.median(dist)
for lab, snr, white in (('real, SNR 0.5', 0.5, False), ('real, SNR 2', 2.0, False), ('real, SNR 20', 20.0, False), ('white, SNR 2', 2.0, True), ('white, SNR 20', 20.0, True)):
    print(lab, 'AP(Q) precision@15 %.2f, median dist %.1f mm' % run(snr, white))
