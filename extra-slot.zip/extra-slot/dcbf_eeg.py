"""Post-hoc, descriptive (NOT in PREREGISTRATION_STEP12.md): DCBF on the Q = 2 realisations of the EEG setting
(same seeds, same data, same grid as Part B), timed the same way (single BLAS thread). DCBF is given the correct
count (it always returns a pair). Compared with AP using 2 slots on the same data (record AP_exactQ in be*.txt).

usage: python3 dcbf_eeg.py PART NPARTS NREP NSTARTS
"""
import paths
import sys, json, time
import numpy as np
sys.path.insert(0, paths.CORE)
import eeg_run as S
from dcbf import DCBF

mo = S.mo
part, nparts, nrep, nstarts = (int(x) for x in sys.argv[1:5])
cells = [(Q, rho, snr) for Q in (2, 3, 4) for rho in (1.0, 0.8, 0.3) for snr in (0.5, 2.0)]
jobs = [(c, k) for c in cells if c[0] == 2 for k in range(nrep)][part::nparts]


def powell_timed(bf, n_starts, rng):
    """dcbf.powell_search with the same logic, plus the best pair and elapsed time after each restart."""
    visited, results, trace = {}, [], []
    best = (-np.inf, None)
    t0 = time.perf_counter()
    for s in range(n_starts):
        r1 = int(rng.integers(bf.p))
        prof = bf.profile(r1); r2 = int(np.argmax(prof)); Z = float(prof[r2])
        path, inherited = [], None
        for _ in range(50):
            key = (min(r1, r2), max(r1, r2))
            if key in visited:
                inherited = visited[key]; break
            path.append(key)
            prof = bf.profile(r2); r1_new = int(np.argmax(prof)); Z = float(prof[r1_new])
            if r1_new == r1:
                break
            r1, r2 = r2, r1_new
        if inherited is None:
            key = (min(r1, r2), max(r1, r2)); results.append((key[0], key[1], Z)); idx = len(results) - 1
            if Z > best[0]:
                best = (Z, key)
        else:
            idx = inherited
        for k in path:
            visited[k] = idx
        trace.append((s + 1, time.perf_counter() - t0, best[1]))
    return trace


for (Q, rho, snr), rep in jobs:
    seed = 700000 + 1000 * cells.index((Q, rho, snr)) + rep
    rng = np.random.default_rng(seed)
    idx, data, eps, Tn = S.simulate(Q, rho, snr, rng)
    pos = S.pos6[idx]
    t = time.perf_counter()
    d = data - data.mean(1, keepdims=True)
    bf = DCBF(S.L7, d @ d.T / d.shape[1], eps)
    prep = time.perf_counter() - t
    trace = powell_timed(bf, nstarts, np.random.default_rng(seed + 17))
    out = dict(Q=Q, rho=rho, snr=snr, rep=rep, seed=seed, prep_sec=prep, res={})
    for n in (10, 100, nstarts):
        _, sec, pair = trace[n - 1]
        Sx = sorted(pair)
        Dm = np.linalg.norm(S.pos7[Sx][:, None] - pos[None], axis=2).min(1) * 1000
        out['res'][f'DCBF{n}'] = dict(found=Sx, prec10=mo.score(Sx, pos, 0.010)['precision'],
                                      prec15=mo.score(Sx, pos, 0.015)['precision'], dist=float(Dm.mean()), sec=sec)
    print(json.dumps(out), flush=True)
