"""How much of the user's-head-model 'floor' is the grid? single source, noise-free, best node > 10 mm away."""
import numpy as np, lf64r_run as S
G, POS, W = S.G, S.POS, S.WALL
Aw = W @ G; An = Aw / np.linalg.norm(Aw, axis=0)
rng = np.random.default_rng(31)
src = [S.pick_sources(1, rng)[0] for _ in range(300)]
def lattice(h):
    key = np.floor(POS / h).astype(int); g = {}
    for i, k in enumerate(map(tuple, key)):
        d = np.linalg.norm(POS[i] - (np.array(k) + 0.5) * h)
        if k not in g or d < g[k][0]: g[k] = (d, i)
    return np.array(sorted(i for _, i in g.values()))
print('single source, noise-free, best grid node > 10 mm from the source (fixed orientations, real-background whitening):')
for lab, idx in (('7 mm lattice (tests)', lattice(0.007)), ('5 mm lattice', lattice(0.005)), ('3.5 mm lattice', lattice(0.0035))):
    err = []
    for k in src:
        cand = idx[idx != k]; e = (An[:, cand].T @ An[:, k]) ** 2
        err.append(np.linalg.norm(POS[cand[np.argmax(e)]] - POS[k]) * 1000)
    err = np.array(err); print(f'   {lab:22s} nodes {len(idx):5d}: {np.mean(err > 10):.2f} (median {np.median(err):.1f} mm)')
err = []
for k in src:
    e = (An.T @ An[:, k]) ** 2; e[k] = -1
    err.append(np.linalg.norm(POS[np.argmax(e)] - POS[k]) * 1000)
err = np.array(err); print(f'   {"all vertices but the source":22s} nodes 15001: {np.mean(err > 10):.2f} (median {np.median(err):.1f} mm)')
