"""Sanity check of the baselines in their intended setting: uncorrelated sources, correct count, SNR 8."""
import numpy as np, eeg_run as S, baselines as B
mo = S.mo
res = {'TRAP': [], 'LCMV': [], 'AP': []}
for i in range(20):
    rng = np.random.default_rng(55000 + i)
    idx, data, eps, Tn = S.simulate(2, 0.0, 8.0, rng)
    f = mo.Fit(data, eps, Tn); pos = S.pos6[idx]
    for k, fn in (('TRAP', lambda: B.trap_music(f, 2)), ('LCMV', lambda: B.lcmv_peaks(f, 2, mo.GRID)), ('AP', lambda: f.ap(2))):
        res[k].append(mo.score(sorted(fn()), pos, 0.010)['precision'])
print('uncorrelated pairs (rho = 0), correct count 2, SNR 8, EEG sample; precision @10 mm over 20 realisations:')
print({k: round(float(np.mean(v)), 2) for k, v in res.items()})
