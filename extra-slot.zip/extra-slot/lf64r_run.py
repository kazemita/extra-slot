"""User's lead field with the real 64-channel BioSemi background (PREREGISTRATION_LF64REAL.md).

Channel mapping from the environment variable LF64_MAP:
  refined   (default, primary)  lead-field rows from refined_order.npy
  rows1-64  (descriptive arm A) rows 1-64 in stored order, as in the user's Main.m
  recovered (descriptive arm B) rows from recovered_order.npy
usage: python3 lf64r_run.py diag     (pre-registered SNR diagnostic)
Used as a module by step12_run.py (setting lf64r)."""
import paths
import os, sys
import numpy as np
import scipy.io as sio
from scipy.signal import butter, sosfiltfilt

sys.path.insert(0, paths.CORE); _here = os.getcwd()
import modelorder as mo
import lsq_generic as lg
os.chdir(_here)
mo.Problem, mo._best_complement, mo._exchange_from = lg.Problem, lg._best_complement, lg._exchange_from

MAP = os.environ.get('LF64_MAP', 'refined')
ROWS = {'refined': lambda: np.load('refined_order.npy'), 'recovered': lambda: np.load('recovered_order.npy'),
        'rows1-64': lambda: np.arange(64)}[MAP]()
G0 = sio.loadmat(paths.LEADFIELD)['gain'][ROWS] * 1e-9      # EDF channel order
POS = sio.loadmat(paths.VOXELS)['l']
m = G0.shape[0]
H = np.eye(m) - np.ones((m, m)) / m                                               # average reference
ev, V = np.linalg.eigh(H); Ur = V[:, ev > 0.5]                                     # 64 x 63
G = Ur.T @ H @ G0
r = G.shape[0]

# --- background: the recording, 1-45 Hz zero-phase, 256 Hz, 2 s trimmed at each end (cached) -----------
FS = 256.0
BG = 'lf64r_bg.npz'
if not os.path.exists(BG):
    import mne
    raw = mne.io.read_raw_edf(paths.EDF,
                              preload=True, verbose=False)
    x = sosfiltfilt(butter(4, [1, 45], btype='band', fs=raw.info['sfreq'], output='sos'), raw.get_data(), axis=1)
    x = x[:, ::4][:, 512:-512]
    np.savez(BG, X=x, ch=np.array(raw.ch_names))
X = Ur.T @ H @ np.load(BG)['X']                                                    # (63, ~60,400)
Ttot = X.shape[1]
C_all = X @ X.T / Ttot
e, V = np.linalg.eigh(C_all); WALL = V @ np.diag(e ** -0.5) @ V.T

# --- grid: same 7 mm lattice subsample as the 70-channel test -------------------------------------------
key = np.floor(POS / 0.007).astype(int)
grid = {}
for i, k in enumerate(map(tuple, key)):
    d = np.linalg.norm(POS[i] - (np.array(k) + 0.5) * 0.007)
    if k not in grid or d < grid[k][0]:
        grid[k] = (d, i)
GRID_IDX = np.array(sorted(i for _, i in grid.values()))
mo.L = G[:, GRID_IDX].T[:, :, None].copy()
mo.GRID = POS[GRID_IDX]; mo.ALL = np.arange(len(GRID_IDX))
nw = np.linalg.norm(WALL @ G, axis=0)
VIS = np.setdiff1d(np.where(nw >= np.percentile(nw, 30))[0], GRID_IDX)            # visible, never on-grid

SOS = butter(4, [5, 35], btype='band', fs=FS, output='sos')
TW = 2048


def pick_sources(Q, rng, min_sep=0.030):
    while True:
        idx = []
        for _ in range(500):
            j = int(rng.choice(VIS))
            if all(np.linalg.norm(POS[j] - POS[i]) >= min_sep for i in idx):
                idx.append(j)
            if len(idx) == Q:
                return idx


def simulate(Q, rho, snr, rng):
    idx = pick_sources(Q, rng)
    w = lambda: (lambda z: z / z.std())(sosfiltfilt(SOS, rng.standard_normal(TW + 600))[300:-300])
    common = w()
    S = np.array([np.sqrt(rho) * common + np.sqrt(1 - rho) * w() for _ in range(Q)]) * rng.uniform(10, 25, Q)[:, None]
    sig = G[:, idx] @ S
    t0 = int(rng.integers(0, Ttot - TW + 1))
    win = X[:, t0:t0 + TW]
    rest = np.concatenate([X[:, :t0], X[:, t0 + TW:]], axis=1)
    sig *= np.sqrt(snr * np.sum((WALL @ win) ** 2) / np.sum((WALL @ sig) ** 2))
    rest = rest - rest.mean(1, keepdims=True)
    return idx, win + sig, rest @ rest.T / rest.shape[1], rest.shape[1]


def ap_restarts(f, q, n, rng):
    S = f.ap(q); best = (f.prob.explained(S), S)
    for _ in range(n - 1):
        Sk = f.polish(list(rng.choice(len(GRID_IDX), q, replace=False))); e_ = f.prob.explained(Sk)
        if e_ > best[0]:
            best = (e_, Sk)
    return best[1]


if __name__ == '__main__' and sys.argv[1] == 'diag':
    print(f'mapping {MAP}: channels {m}, rank {r}, background {Ttot / FS:.0f} s, grid nodes {len(GRID_IDX)}, '
          f'simulation candidates {len(VIS)}')
    p15 = {0.5: [], 2.0: []}
    for i in range(36):
        snr = (0.5, 2.0)[i % 2]; Q = 2 + (i // 2) % 3; rho = (1.0, 0.8, 0.3)[(i // 6) % 3]
        rng = np.random.default_rng(594000 + i)
        idx, data, eps, Tn = simulate(Q, rho, snr, rng)
        f = mo.Fit(data, eps, Tn)
        p15[snr].append(mo.score(f.ap(Q), POS[idx], 0.015)['precision'])
    allp = p15[0.5] + p15[2.0]
    print('correct-count precision@15: SNR 0.5 %.2f, SNR 2 %.2f, pooled %.2f -> use SNR %s'
          % (np.mean(p15[0.5]), np.mean(p15[2.0]), np.mean(allp), '{0.5, 2}' if np.mean(allp) >= 0.70 else '{2, 8}'))
