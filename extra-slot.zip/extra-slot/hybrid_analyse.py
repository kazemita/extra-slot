"""Pre-registered analysis of the hybrid test (PREREGISTRATION.md)."""
import json, glob, sys, numpy as np
pattern = sys.argv[1] if len(sys.argv) > 1 else 'hy[0-9].txt'
rows = [json.loads(l) for f in sorted(glob.glob(pattern)) for l in open(f)]
M = ['AP', 'AP6', 'ESnp+1', 'ESnp+2']

def ci(d, seed=0):
    b = np.random.default_rng(seed).choice(d, (4000, len(d))).mean(1)
    return np.percentile(b, [2.5, 97.5])

print(f'{len(rows)} realisations\n')
valid = np.mean([r['res']['AP_exactQ']['prec15'] for r in rows])
print(f'VALIDITY: AP with correct count, pooled precision @15 mm = {valid:.3f} (must be >= 0.60) -> '
      f'{"valid" if valid >= 0.6 else "INVALID"}\n')
d = np.array([r['res']['ESnp+1']['prec10'] - r['res']['AP6']['prec10'] for r in rows])
lo, hi = ci(d)
dec = 'GO' if (d.mean() >= 0.10 and lo > 0) else ('MODEST' if lo > 0 else 'NO-GO')
print(f'PRIMARY: precision @10 mm, ESnp+1 - AP6 = {d.mean():+.3f} [95% CI {lo:+.3f}, {hi:+.3f}], '
      f'better/worse/tie {(d > 1e-9).sum()}/{(d < -1e-9).sum()}/{(abs(d) <= 1e-9).sum()}  ->  DECISION: {dec}\n')

print('SECONDARY (not decisive)')
for met, lab in (('prec10', 'precision @10 mm'), ('prec15', 'precision @15 mm'), ('dist', 'mean distance to nearest true (mm)')):
    print(f'  {lab:<36}' + '  '.join(f'{m} {np.mean([r["res"][m][met] for r in rows]):6.3f}' for m in M))
for m in ('ESnp+2',):
    dd = np.array([r['res'][m]['prec10'] - r['res']['AP6']['prec10'] for r in rows]); l2, h2 = ci(dd)
    print(f'  {m} - AP6, precision @10 mm: {dd.mean():+.3f} [{l2:+.3f}, {h2:+.3f}]')
dd = np.array([r['res']['ESnp+1']['dist'] - r['res']['AP6']['dist'] for r in rows]); l2, h2 = ci(dd)
print(f'  ESnp+1 - AP6, mean distance (mm): {dd.mean():+.2f} [{l2:+.2f}, {h2:+.2f}]')
print(f'  AP6 explains >= power than ESnp+1 in {100*np.mean([r["res"]["AP6"]["expl"] >= r["res"]["ESnp+1"]["expl"] - 1e-9 for r in rows]):.0f}% of realisations')
for key in ('rho', 'Q', 'snr'):
    print(f'\n  by {key}:')
    for v in sorted({r[key] for r in rows}, reverse=True):
        R = [r for r in rows if r[key] == v]
        dv = np.array([r['res']['ESnp+1']['prec10'] - r['res']['AP6']['prec10'] for r in R]); l2, h2 = ci(dv)
        print(f'    {key}={v}: n={len(R)}  AP6 {np.mean([r["res"]["AP6"]["prec10"] for r in R]):.3f}  '
              f'ESnp+1 {np.mean([r["res"]["ESnp+1"]["prec10"] for r in R]):.3f}  diff {dv.mean():+.3f} [{l2:+.3f}, {h2:+.3f}]')
