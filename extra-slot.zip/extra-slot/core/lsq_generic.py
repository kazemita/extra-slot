"""
GENERIC-ORIENTATION version of lsq_methods.py (any number of orientations per node, e.g. 3 for EEG).
Only Problem, the scores, shortlist, residuals and the exchange step are generalised; identical results
to lsq_methods.py when every node has 2 orientations (checked in test_lsq_generic.py).

Python ports of recursive_sloreta.m, joint_pair_localize.m and exchange_localize.m,
adapted to the DCBF simulation setting.

Two adaptations are needed (the MATLAB versions assume a single snapshot g and one
fixed-orientation column per candidate):

1. Dipoles with unknown orientation.  Every grid location carries a 2-column lead
   field (radial direction removed by SVD, as in the DCBF paper).  Each location is
   treated as a *group atom*: its two columns are orthonormalised (the vector analogue
   of "unit-norm columns"), and every "correlation", "explained power" and "best
   complement" calculation uses the projection onto that 2-D span instead of onto a
   single column.  For one fixed-orientation column these reduce exactly to the
   MATLAB formulas.

2. Many time samples instead of one snapshot.  The data are whitened with the
   noise covariance (eps^-1/2), and the single snapshot g is replaced by the
   whitened signal subspace G = V_k * sqrt(lambda_k - 1) (m x k), where k counts the
   eigenvalues above the noise edge (Wachter edge for a sample-whitened covariance).  Every ||.||^2 becomes a
   Frobenius norm.  For fully correlated sources k = 1, i.e. G is a single
   denoised "snapshot", exactly the situation the MATLAB code was written for.

Everything else (adaptive rel_thresh pool + sLORETA ranking, refit of all found
sources against the original data, hybrid shortlist of top-400 by correlation and
by sLORETA, closed-form joint pair search, greedy-initialised exchange search with
random restarts) follows the MATLAB code.

Also added: over-provisioned exchange ("extra slots"): run the exchange search with
r_extra > r slots, then prune to the r-subset that explains the most power, then
polish with an r-slot exchange started from that subset.
"""
import itertools
import numpy as np


# ----------------------------------------------------------------------------
# Preparation: whitening, group atoms, signal subspace
# ----------------------------------------------------------------------------
class Problem:
    def __init__(self, L, B, eps, eps_samples, k=None, mp_margin=1.2, k_max=10):
        """L (p, m, 2) reduced lead fields; B (m, T) data; eps (m, m) noise cov."""
        p, m, no = L.shape
        self.no = no
        T = B.shape[1]
        ev, V = np.linalg.eigh(eps)
        W = V @ np.diag(ev ** -0.5) @ V.T                 # eps^-1/2
        self.W = W
        Lf = L.transpose(1, 0, 2).reshape(m, no * p)
        self.Lw = (W @ Lf).reshape(m, p, no).transpose(1, 0, 2).copy()   # whitened lead fields
        U, s, _ = np.linalg.svd(self.Lw, full_matrices=False)
        self.U = U                                        # (p, m, 2) orthonormal group atoms
        self.Uflat = U.transpose(1, 0, 2).reshape(m, no * p)
        self.Bw = W @ B
        Cw = self.Bw @ self.Bw.T / T
        lam, Vc = np.linalg.eigh(Cw)
        lam, Vc = lam[::-1], Vc[:, ::-1]
        # noise edge for data whitened by a *sample* noise covariance (ratio of two
        # Wishart matrices; Wachter 1980): reduces to Marchenko-Pastur when N -> inf
        g1, g2 = m / T, m / eps_samples
        edge = ((1 + np.sqrt(1 - (1 - g1) * (1 - g2))) / (1 - g2)) ** 2
        if k is None:
            k = int(np.clip(np.sum(lam > mp_margin * edge), 1, k_max))
        self.k = k
        self.G = Vc[:, :k] * np.sqrt(np.maximum(lam[:k] - 1.0, 1e-12))
        self.p, self.m = p, m
        self._sl = None

    # --- per-location scores against a residual R (m x k) ---------------------
    def corr_score(self, R):
        """Vector analogue of |K' r|: ||U_j' R||_F (projection energy)."""
        A = (self.Uflat.T @ R).reshape(self.p, self.no, -1)
        return np.sqrt(np.sum(A ** 2, axis=(1, 2)))

    def sloreta_prep(self, lam=None):
        if self._sl is None:
            K = self.Uflat
            if lam is None:
                lam = 1e-3 * np.trace(K @ K.T) / self.m   # MATLAB default
            Ainv = np.linalg.inv(K @ K.T + lam * np.eye(self.m))
            Z = (Ainv @ K).reshape(self.m, self.p, self.no).transpose(1, 0, 2)
            Rjj = np.einsum('pmi,pmj->pij', self.U, Z)    # 2x2 resolution blocks
            self._sl = (Ainv, np.linalg.inv(Rjj))
        return self._sl

    def sloreta_score(self, R):
        """Vector sLORETA: trace(x_j' R_jj^-1 x_j), x_j = U_j' A^-1 R."""
        Ainv, Rinv = self.sloreta_prep()
        X = (self.Uflat.T @ (Ainv @ R)).reshape(self.p, self.no, -1)
        return np.einsum('pik,pij,pjk->p', X, Rinv, X)

    def explained(self, support, G=None):
        G = self.G if G is None else G
        A = np.concatenate([self.U[j] for j in support], axis=1)
        Q, _ = np.linalg.qr(A)
        return np.sum((Q.T @ G) ** 2)

    def quality(self, support):
        return self.explained(support) / np.sum(self.G ** 2)

    def shortlist(self, size=400):
        c = self.corr_score(self.G); s = self.sloreta_score(self.G)
        return np.union1d(np.argsort(-c)[:size], np.argsort(-s)[:size])

    # --- amplitude/orientation read-out: least squares on ALL data -------------
    def fit_timecourses(self, support):
        Ls = np.concatenate([self.Lw[j] for j in support], axis=1)   # m x 2r
        return np.linalg.lstsq(Ls, self.Bw, rcond=None)[0]           # 2r x T (nAm)


def _residual(prob, support):
    if len(support) == 0:
        return prob.G.copy()
    A = np.concatenate([prob.U[j] for j in support], axis=1)
    Q, _ = np.linalg.qr(A)
    return prob.G - Q @ (Q.T @ prob.G)


# ----------------------------------------------------------------------------
# recursive_sloreta.m
# ----------------------------------------------------------------------------
def recursive_sloreta(prob, r, rel_thresh=0.3):
    found = []
    R = prob.G.copy()
    for _ in range(r):
        Ru = R / np.linalg.norm(R)
        c = prob.corr_score(Ru)
        c[found] = -1
        pool = np.where(c >= rel_thresh * c.max())[0]
        S = prob.sloreta_score(Ru)
        Sr = np.full(prob.p, -np.inf); Sr[pool] = S[pool]
        found.append(int(np.argmax(Sr)))
        R = _residual(prob, found)          # refit ALL found against the original G
    return found


# ----------------------------------------------------------------------------
# joint_pair_localize.m
# ----------------------------------------------------------------------------
def joint_pair_localize(prob, shortlist_size=400):
    sl = prob.shortlist(shortlist_size)
    Us = prob.U[sl]                                  # (M, m, 2)
    a = np.einsum('pmi,mk->pik', Us, prob.G)         # (M, 2, k)
    best = (-np.inf, -1, -1)
    for ii in range(len(sl) - 1):
        jj = np.arange(ii + 1, len(sl))
        C = np.einsum('mi,pmj->pij', Us[ii], Us[jj])  # (n, 2, 2) mutual coherence blocks
        n = len(jj)
        M = np.zeros((n, 4, 4)); M[:, :2, :2] = np.eye(2); M[:, 2:, 2:] = np.eye(2)
        M[:, :2, 2:] = C; M[:, 2:, :2] = C.transpose(0, 2, 1)
        y = np.concatenate([np.broadcast_to(a[ii], (n,) + a[ii].shape), a[jj]], axis=1)  # (n,4,k)
        ok = np.linalg.cond(M) < 1e6
        expl = np.full(n, -np.inf)
        if ok.any():
            sol = np.linalg.solve(M[ok], y[ok])
            expl[ok] = np.einsum('pik,pik->p', y[ok], sol)
        j = int(np.argmax(expl))
        if expl[j] > best[0]:
            best = (expl[j], int(sl[ii]), int(sl[jj[j]]))
    return [best[1], best[2]]


# ----------------------------------------------------------------------------
# exchange_localize.m
# ----------------------------------------------------------------------------
def _best_complement(prob, backbone, cand):
    """Group-OMP step: candidate whose 2-D span, orthogonalised against the backbone,
    captures the most of the backbone residual.  Uses Rb _|_ span(backbone), so
    Cp_j' Rb = U_j' Rb and Gram_j = I - (Qb' U_j)' (Qb' U_j)  (all BLAS, no loops)."""
    cand = np.asarray(cand)
    no = prob.no
    cols = (no * cand[:, None] + np.arange(no)).ravel()
    Uc = prob.Uflat[:, cols]                                   # m x 2n
    if backbone:
        A = np.concatenate([prob.U[j] for j in backbone], axis=1)
        Qb, _ = np.linalg.qr(A)
        Rb = prob.G - Qb @ (Qb.T @ prob.G)
        P = (Qb.T @ Uc).reshape(Qb.shape[1], -1, no)
        Gram = np.eye(no) - np.einsum('qni,qnj->nij', P, P)
    else:
        Rb = prob.G
        Gram = np.broadcast_to(np.eye(no), (len(cand), no, no))
    g = (Uc.T @ Rb).reshape(-1, no, Rb.shape[1])
    gains = np.einsum('pik,pik->p', g, np.linalg.solve(Gram + 1e-10 * np.eye(no), g))
    return int(cand[int(np.argmax(gains))])


def _greedy_init(prob, r, sl):
    support = []
    for _ in range(r):
        cand = np.setdiff1d(sl, support)
        c = prob.corr_score(_residual(prob, support))[cand]
        support.append(int(cand[int(np.argmax(c))]))
    return support


def _exchange_from(prob, support, sl, max_passes=10):
    support = list(support)
    for _ in range(max_passes):
        changed = False
        for pos in range(len(support)):
            B = support[:pos] + support[pos + 1:]
            cand = np.setdiff1d(sl, B)
            best = _best_complement(prob, B, cand)
            if best != support[pos]:
                support[pos] = best; changed = True
        if not changed:
            break
    return support


def exchange_localize(prob, r, shortlist_size=400, max_passes=10, n_restarts=1,
                      rng=None, sl=None, full_check=False):
    """full_check=True (an addition to the MATLAB version): after the shortlist
    search converges, keep exchanging with the WHOLE grid as candidates, so a true
    source that never made the shortlist can still be swapped in."""
    rng = np.random.default_rng(rng)
    sl = prob.shortlist(shortlist_size) if sl is None else sl
    best_s, best_q = None, -np.inf
    for rs in range(n_restarts):
        init = _greedy_init(prob, r, sl) if rs == 0 else list(rng.choice(sl, r, replace=False))
        s = _exchange_from(prob, init, sl, max_passes)
        if full_check:
            s = _exchange_from(prob, s, np.arange(prob.p), max_passes)
        q = prob.quality(s)
        if q > best_q:
            best_s, best_q = s, q
    return sorted(best_s), best_q


# ----------------------------------------------------------------------------
# "Extra slots": over-provisioned exchange, then prune to r and polish
# ----------------------------------------------------------------------------
def extra_slot_localize(prob, r, r_extra, shortlist_size=400, n_restarts=1, rng=None,
                        full_check=False):
    sl = prob.shortlist(shortlist_size)
    big, _ = exchange_localize(prob, r_extra, n_restarts=n_restarts, rng=rng, sl=sl,
                               full_check=full_check)
    best = max(itertools.combinations(big, r), key=lambda s: prob.explained(s))
    polished = _exchange_from(prob, list(best), np.arange(prob.p) if full_check else sl)
    return sorted(polished), sorted(best), big
