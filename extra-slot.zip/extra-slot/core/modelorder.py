"""
Pilot: does over-provisioning ("extra slots") make alternating-projection-type source
localisation robust when the number of sources is misjudged or unknown?

Design principle: every method uses the SAME search machinery (whole-grid exchange /
alternating-projection step from lsq_methods.py) and, where a source count is chosen
from the data, the SAME stopping statistic and threshold.  The only thing that differs
between AP and the extra-slot methods is the slot strategy.

Methods
  AP(q)        alternating projection as published (Adler, Wax & Pantazis): sequential
               initialisation (each new source = best complement to those already found),
               then cyclic re-estimation of each source with the others fixed, whole grid.
  ES(q, R)     extra slots: AP fit with R > q slots, keep the q-subset explaining the most
               power, polish with AP iterations at q slots.
  ESnp(q, R)   the same without the final polish (the kept slots stay where the R-slot fit put them).
  AP-forward   unknown count: fit AP(1), AP(2), ...; stop when the gain from one more
               source is below the threshold.
  AP-MDL       unknown count: q = signal-subspace rank (eigenvalues above noise edge), then AP(q)
               (the eigenvalue-based model-order route suggested in the AP paper).
  ES-backward  unknown count: AP fit with R = 6 slots, then repeatedly drop the slot whose
               removal (with re-polish) costs least, while that cost is below the threshold.

Simulation (deliberately harder than the DCBF tests)
  * sources OFF the reconstruction grid (random positions in a 5.5-8 cm shell, z >= 0,
    >= 30 mm apart), random tangential orientations, rms amplitudes 10-25 nAm;
  * band-limited (5-35 Hz) random waveforms with pairwise correlation rho:
    s_i = sqrt(rho) c + sqrt(1-rho) e_i   (rho = 1 -> fully coherent);
  * white sensor noise at a given SNR, separate noise segment for the noise covariance.
"""
import itertools, time, json, sys
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.signal import butter, sosfiltfilt
from dcbf import lead_field_3, make_sensor_array
from lsq_methods import Problem, _best_complement, _exchange_from

try:                                   # spherical pilot model (not needed for the realistic-head scripts,
    M = np.load('model.npz')           # which set L, GRID and ALL themselves)
    GRID, L = M['grid'], M['L']
except FileNotFoundError:
    GRID = L = None
SENS = make_sensor_array()
FS = 1000
ALL = np.arange(len(GRID)) if GRID is not None else None
SOS = butter(4, [5, 35], btype='band', fs=FS, output='sos')


# ----------------------------------------------------------------------------- simulation
def random_sources(Q, rng, rmin=0.055, rmax=0.080, min_sep=0.030):
    pos = []
    while len(pos) < Q:
        v = rng.standard_normal(3); v /= np.linalg.norm(v)
        if v[2] < 0:
            continue
        x = v * rng.uniform(rmin, rmax)
        if all(np.linalg.norm(x - y) >= min_sep for y in pos):
            pos.append(x)
    return np.array(pos)


def simulate(Q, rho, snr, rng, T=3000, Tn=3000):
    pos = random_sources(Q, rng)
    topo = []
    for x in pos:
        L3 = lead_field_3(x, SENS)
        _, _, Vt = np.linalg.svd(L3, full_matrices=False)
        ori = Vt[:2].T @ (lambda a: np.array([np.cos(a), np.sin(a)]))(rng.uniform(0, 2 * np.pi))
        topo.append(L3 @ ori)                                  # tangential dipole, 1 nAm
    topo = np.array(topo).T                                    # m x Q
    w = lambda: (lambda z: z / z.std())(sosfiltfilt(SOS, rng.standard_normal(T + 400))[200:-200])
    common = w()
    S = np.array([np.sqrt(rho) * common + np.sqrt(1 - rho) * w() for _ in range(Q)])
    S *= rng.uniform(10, 25, Q)[:, None]                       # rms nAm
    b = topo @ S
    sigma = np.sqrt(np.mean(b ** 2) / snr)
    data = b + sigma * rng.standard_normal(b.shape)
    noise = sigma * rng.standard_normal((b.shape[0], Tn))
    return pos, data, noise @ noise.T / Tn


# ----------------------------------------------------------------------------- criteria
class Fit:
    """Wraps lsq_methods.Problem and adds the full-data explained power tr(P_S Cw)."""
    def __init__(self, data, eps, Tn):
        self.prob = Problem(L, data, eps, Tn)
        self.Cw = self.prob.Bw @ self.prob.Bw.T / data.shape[1]
        self.cache = {}

    def expl(self, S):                       # per-sample whitened power explained (full data)
        key = tuple(sorted(S))
        if key not in self.cache:
            if not S:
                self.cache[key] = 0.0
            else:
                Q_, _ = np.linalg.qr(np.concatenate([self.prob.U[j] for j in key], 1))
                self.cache[key] = float(np.trace(Q_.T @ self.Cw @ Q_))
        return self.cache[key]

    # AP as published: sequential init with projection, then cyclic re-estimation
    def ap(self, q):
        S = []
        for _ in range(q):
            S.append(_best_complement(self.prob, S, np.setdiff1d(ALL, S)))
        return sorted(_exchange_from(self.prob, S, ALL, max_passes=20))

    def polish(self, S):
        return sorted(_exchange_from(self.prob, list(S), ALL, max_passes=20))

    def es_fixed(self, q, R):
        big = self.ap(R)
        best = max(itertools.combinations(big, q), key=lambda s: self.prob.explained(list(s)))
        return self.polish(best), big, sorted(best)

    def ap_forward(self, theta, qmax=6):
        prev, prev_e = [], 0.0
        for q in range(1, qmax + 1):
            S = self.ap(q); e = self.expl(S)
            if e - prev_e < theta:
                return prev
            prev, prev_e = S, e
        return prev

    def ap_mdl(self):
        return self.ap(self.prob.k), self.prob.k

    def es_backward(self, theta, R=6):
        S = self.ap(R)
        while len(S) > 1:
            best = None
            for j in S:
                Sj = self.polish([x for x in S if x != j])
                cost = self.expl(S) - self.expl(Sj)
                if best is None or cost < best[0]:
                    best = (cost, Sj)
            if best[0] >= theta:
                break
            S = best[1]
        return S


# ----------------------------------------------------------------------------- scoring
def score(found, pos, tol=0.010):
    found = list(found)
    if not found:
        return dict(recall=0.0, precision=1.0, n_found=0, err_mm=None)
    D = np.linalg.norm(pos[:, None] - GRID[found][None], axis=2)        # true x found
    r, c = linear_sum_assignment(D)
    hit = D[r, c] <= tol
    return dict(recall=hit.sum() / len(pos), precision=hit.sum() / len(found),
                n_found=len(found), err_mm=float(D[r, c].mean() * 1000))
