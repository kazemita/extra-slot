"""Try to recover which lead-field row is which BioSemi electrode, using only the lead field's geometry,
then check the recovered order against the recording (independent evidence)."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import paths
import numpy as np, scipy.io as sio, mne
from scipy.optimize import linear_sum_assignment
from scipy.stats import spearmanr
from scipy.signal import butter, sosfiltfilt

def est_positions(G, loc, frac_outer=0.3, ntop=30):
    Ga = G - G.mean(0)
    cen = loc.mean(0); rad = np.linalg.norm(loc - cen, axis=1)
    sup = rad >= np.percentile(rad, 100 * (1 - frac_outer))
    out = []
    for i in range(G.shape[0]):
        w = Ga[i, sup] ** 2; top = np.argsort(-w)[:ntop]
        out.append(np.average(loc[sup][top], axis=0, weights=w[top]))
    return np.array(out)

def sim_fit(A, B):
    """similarity transform (s, R, t) minimising ||s A R + t - B||"""
    ma, mb = A.mean(0), B.mean(0); a, b = A - ma, B - mb
    U, S, Vt = np.linalg.svd(a.T @ b); D = np.eye(3); D[2, 2] = np.sign(np.linalg.det(U @ Vt))
    R = U @ D @ Vt; s = np.trace(np.diag(S) @ D) / np.sum(a ** 2)
    return lambda X: s * (X - ma) @ R + mb

# ---- does the position estimate work? check on the known sample case --------------------------------------
TD = paths.TD
fwd = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', verbose=False)
fwd = mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
fwd = mne.pick_types_forward(fwd, meg=False, eeg=True, exclude='bads')
info = mne.io.read_info(TD + 'MEG/sample/sample_audvis_trunc_raw.fif', verbose=False)
P = np.array([info['chs'][info.ch_names.index(c)]['loc'][:3] for c in fwd['sol']['row_names']])
E = est_positions(fwd['sol']['data'], fwd['source_rr'])
f = sim_fit(E, P); rms = np.sqrt(np.mean(np.sum((f(E) - P) ** 2, 1)))
cost = np.linalg.norm(f(E)[:, None] - P[None], axis=2); r_, c_ = linear_sum_assignment(cost)
print(f'sample (known): position estimate rms error after similarity fit {rms * 1000:.0f} mm; '
      f'nearest-assignment recovers {np.mean(c_ == r_):.2f} of channels')

# ---- user ------------------------------------------------------------------------------------------------
G = sio.loadmat(paths.LEADFIELD)['gain']
loc = sio.loadmat(paths.VOXELS)['l']
raw = mne.io.read_raw_edf(paths.EDF, preload=True, verbose=False)
ch = raw.ch_names
mp = mne.channels.make_standard_montage('biosemi64').get_positions()['ch_pos']
T = np.array([mp[c] for c in ch])
E = est_positions(G, loc)                                               # 70 x 3, Brainstorm-like frame
# start: SCS (x anterior, y left, z up) -> MNE head (x right, y anterior, z up); then iterate assignment + fit
E0 = np.c_[-E[:, 1], E[:, 0], E[:, 2]]
best = None
for flip in ([1, 1, 1], [-1, 1, 1], [1, -1, 1], [-1, -1, 1]):          # tolerate a left/right or front/back flip
    X = E0 * flip
    X = (X - X.mean(0)) / np.sqrt(np.mean(np.sum((X - X.mean(0)) ** 2, 1))) * np.sqrt(np.mean(np.sum((T - T.mean(0)) ** 2, 1))) + T.mean(0)
    for it in range(50):
        cost = np.linalg.norm(X[:, None] - T[None], axis=2)              # 70 rows x 64 electrodes
        rows, cols = linear_sum_assignment(cost)                         # each electrode gets one row, 6 rows unused
        f = sim_fit(E0[rows] * flip, T[cols]); Xn = f(E0 * flip)
        if np.allclose(Xn, X):
            break
        X = Xn
    res = np.sqrt(np.mean(cost[rows, cols] ** 2))
    if best is None or res < best[0]:
        best = (res, flip, rows, cols)
res, flip, rows, cols = best
order = np.full(64, -1); order[cols] = rows                              # order[k] = lead-field row for EDF channel k
print(f'user: assignment rms {res * 1000:.0f} mm (flip {flip}); unused lead-field rows: {sorted(set(range(70)) - set(rows.tolist()))}')
print('first 20 EDF channels -> lead-field row (1-based):', [(ch[k], int(order[k]) + 1) for k in range(20)])
print('channels already where Main.m assumes (row k = channel k):', int(np.sum(order == np.arange(64))), 'of 64')
# ---- independent check against the recording: how similar is the EEG correlation structure? -------------
Xb = raw.get_data()[:, ::4]
sos = butter(4, [1, 40], btype='band', fs=256, output='sos'); Xf = sosfiltfilt(sos, Xb - Xb.mean(0), axis=1)
Ce = np.corrcoef(Xf); iu = np.triu_indices(64, 1)
def ecorr(rows_):
    g = G[rows_] - G[rows_].mean(0); return spearmanr(np.corrcoef(g)[iu], Ce[iu])[0]
D = np.linalg.norm(T[:, None] - T[None], axis=2); nn4 = np.argsort(D, 1)[:, 1:5]
def nb(rows_):
    g = G[rows_] - G[rows_].mean(0); C = np.corrcoef(g); np.fill_diagonal(C, -np.inf); b = np.argmax(C, 1)
    return np.mean([b[i] in nn4[i] for i in range(64)])
print(f'\nrecording vs lead field (calibration: correct mapping ~0.84, shifted-by-6 ~0.28, random ~0):')
print(f'   rows 1-64 (Main.m):  Spearman {ecorr(np.arange(64)):.2f}   near-neighbour {nb(np.arange(64)):.2f}')
print(f'   recovered order:     Spearman {ecorr(order):.2f}   near-neighbour {nb(order):.2f}')
np.save('recovered_order.npy', order)
