"""(a) refine the recovered order with swaps, using ONLY the lead field + BioSemi template (no recording);
(b) re-check against the recording; (c) label the 6 unused rows; (d) inspect the background segment Main.m uses."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import paths
import numpy as np, scipy.io as sio, mne
from scipy.stats import spearmanr
from scipy.signal import butter, sosfilt, sosfiltfilt, welch

G = sio.loadmat(paths.LEADFIELD)['gain']; Ga = G - G.mean(0)
raw = mne.io.read_raw_edf(paths.EDF, preload=True, verbose=False)
ch = raw.ch_names; X = raw.get_data()
mp = mne.channels.make_standard_montage('biosemi64').get_positions()['ch_pos']
T = np.array([mp[c] for c in ch]); D = np.linalg.norm(T[:, None] - T[None], axis=2); iu = np.triu_indices(64, 1)
Cr = np.corrcoef(Ga)
order = np.load('recovered_order.npy')

def geo_score(o):                                    # lead field + template only
    return spearmanr(Cr[np.ix_(o, o)][iu], -D[iu])[0]

s0 = geo_score(order); improved = True; o = order.copy()
while improved:
    improved = False
    for i in range(64):
        for j in list(range(i + 1, 64)) + [-(k + 1) for k in sorted(set(range(70)) - set(o.tolist()))]:
            o2 = o.copy()
            if j >= 0: o2[i], o2[j] = o[j], o[i]
            else: o2[i] = -j - 1                     # swap in an unused row
            s = geo_score(o2)
            if s > s0 + 1e-6:
                o, s0, improved = o2, s, True
print(f'geometry score (Spearman, lead-field similarity vs closeness): recovered {geo_score(order):.3f} -> refined {s0:.3f}; '
      f'{int(np.sum(o != order))} channels changed')

Xb = X[:, ::4]; sos = butter(4, [1, 40], btype='band', fs=256, output='sos'); Xf = sosfiltfilt(sos, Xb - Xb.mean(0), axis=1)
Ce = np.corrcoef(Xf)
def ecorr(r):
    g = G[r] - G[r].mean(0); return spearmanr(np.corrcoef(g)[iu], Ce[iu])[0]
print(f'recording check (independent): rows 1-64 {ecorr(np.arange(64)):.2f} | recovered {ecorr(order):.2f} | refined {ecorr(o):.2f}  (known-correct calibration 0.84)')
np.save('refined_order.npy', o)
unused = sorted(set(range(70)) - set(o.tolist()))
print('unused lead-field rows (1-based):', [u + 1 for u in unused])
print('\nEDF channel -> lead-field row (1-based), refined:')
print(', '.join(f'{ch[k]}:{o[k] + 1}' for k in range(64)))
# label the unused rows by their most similar assigned rows
for u in unused:
    nb = np.argsort(-Cr[u, o])[:3]
    print(f'   unused row {u + 1}: most similar to {[ch[k] for k in nb]} (r = {np.round(Cr[u, o][nb], 2).tolist()})')

# ---- (d) the background segment as Main.m builds it ----------------------------------------------------
sosM = butter(10, [5, 80], btype='bandpass', fs=1024, output='sos')         # = designfilt(..., 'FilterOrder', 20)
F = sosfilt(sosM, X, axis=1)                                                # causal, no re-referencing (as Main.m)
seg = F[:, 6635:6635 + 1024]
cm = seg.mean(0)
print(f'\nMain.m background segment (1 s from sample 6636, 5-80 Hz, no re-reference):')
print(f'   common-mode share of variance: {np.var(cm) / np.mean(np.var(seg, 1)):.2f}')
f, P = welch(F[:, 20000:-20000], fs=1024, nperseg=2048)
line = P[:, (f > 49) & (f < 51)].sum(1) / P[:, (f >= 5) & (f <= 80)].sum(1)
fa, Pa = welch(F[:, 20000:-20000] - F[:, 20000:-20000].mean(0), fs=1024, nperseg=2048)
linea = Pa[:, (fa > 49) & (fa < 51)].sum(1) / Pa[:, (fa >= 5) & (fa <= 80)].sum(1)
print(f'   49-51 Hz share of 5-80 Hz power (whole recording): median {np.median(line):.3f} (after average reference {np.median(linea):.3f})')
alpha = P[:, (f >= 8) & (f <= 12)].sum(1) / P[:, (f >= 5) & (f <= 80)].sum(1)
print(f'   8-12 Hz share of 5-80 Hz power: median {np.median(alpha):.2f}')
