"""Calibrate the channel-order tests on a case where the mapping is KNOWN (MNE sample subject: 60-ch EEG,
BEM forward, recorded resting/ongoing EEG), then apply the identical tests to the user's lead field (rows 1-64)
and the BioSemi recording."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import paths
import numpy as np, scipy.io as sio, mne
from scipy.stats import spearmanr
from scipy.signal import butter, sosfiltfilt

def tests(G, pos, X, fs, rng, label, nnull=1000):
    """G (m, n) lead field rows in the hypothesised channel order; pos (m, 3) electrode positions in that order;
    X (m, T) recorded EEG in that order."""
    m = G.shape[0]
    Ga = G - G.mean(0)
    Cr = np.corrcoef(Ga)
    D = np.linalg.norm(pos[:, None] - pos[None], axis=2)
    iu = np.triu_indices(m, 1)
    nn4 = np.argsort(D, 1)[:, 1:5]                                  # 4 nearest electrodes of each channel
    sos = butter(4, [1, 40], btype='band', fs=fs, output='sos')
    Xf = sosfiltfilt(sos, X - X.mean(0), axis=1)
    Ce = np.corrcoef(Xf)
    def stats(perm):
        C = Cr[np.ix_(perm, perm)].copy(); np.fill_diagonal(C, -np.inf)
        best = np.argmax(C, 1)
        a = np.mean([best[i] in nn4[i] for i in range(m)])            # best partner among 4 nearest electrodes
        b = spearmanr(Cr[np.ix_(perm, perm)][iu], -D[iu])[0]          # lead-field similarity vs closeness
        c = spearmanr(np.corrcoef(Ga[perm])[iu], Ce[iu])[0]           # lead-field vs recorded EEG correlations
        return a, b, c
    obs = stats(np.arange(m))
    null = np.array([stats(rng.permutation(m)) for _ in range(nnull)])
    names = ('best partner is a near neighbour', 'Spearman(lead-field similarity, closeness)',
             'Spearman(lead-field corr, EEG corr)')
    print(f'\n{label}')
    for k in range(3):
        print(f'   {names[k]:45s} {obs[k]:6.2f}   (random orders: median {np.median(null[:, k]):5.2f}, '
              f'99th pct {np.percentile(null[:, k], 99):5.2f})')
    return obs

rng = np.random.default_rng(0)
TD = paths.TD
# ---- known mapping: MNE sample ---------------------------------------------------------------------------
fwd = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', verbose=False)
fwd = mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
fwd = mne.pick_types_forward(fwd, meg=False, eeg=True, exclude='bads')
raw = mne.io.read_raw_fif(TD + 'MEG/sample/sample_audvis_trunc_raw.fif', preload=True, verbose=False)
raw.pick(fwd['sol']['row_names'])
pos = np.array([raw.info['chs'][raw.ch_names.index(c)]['loc'][:3] for c in fwd['sol']['row_names']])
Xs = raw.get_data(picks=fwd['sol']['row_names'])
tests(fwd['sol']['data'], pos, Xs, raw.info['sfreq'], rng, f'KNOWN mapping, MNE sample ({len(pos)} ch, realistic BEM)')
# a deliberately wrong but 'locally sensible' order: rotate the channel list by 6 (mimics an offset error)
sh = np.roll(np.arange(len(pos)), 6)
tests(fwd['sol']['data'][sh], pos, Xs, raw.info['sfreq'], rng, 'MNE sample, rows shifted by 6 (known WRONG)')

# ---- user: lead field rows 1-64 vs BioSemi recording -----------------------------------------------------
G = sio.loadmat(paths.LEADFIELD)['gain']
r2 = mne.io.read_raw_edf(paths.EDF, preload=True, verbose=False)
mp = mne.channels.make_standard_montage('biosemi64').get_positions()['ch_pos']
posb = np.array([mp[c] for c in r2.ch_names])
Xb = r2.get_data()[:, ::4]                                          # 256 Hz is plenty for a 1-40 Hz test
tests(G[:64], posb, Xb, r2.info['sfreq'] / 4, rng, 'USER: lead-field rows 1-64 as BioSemi channels in EDF order')
tests(G[6:70], posb, Xb, r2.info['sfreq'] / 4, rng, 'USER: lead-field rows 7-70 as BioSemi channels in EDF order')
