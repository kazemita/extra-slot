"""EEG decisive hybrid test (see PREREGISTRATION_EEG.md); copy of hybrid_run.py with EEG inputs,
three orientations per grid node (lsq_generic) and seeds 700000+. Simulated cortical sources added to real MEG background;
methods fitted with Q-1 slots. One JSON line per realisation.

usage: python3 eeg_run.py PART NPARTS NREP [SEED0]
"""
import paths
import os, sys, json, time
import numpy as np
from scipy.signal import butter, sosfiltfilt

sys.path.insert(0, paths.CORE); _here = os.getcwd()           # modelorder loads model.npz on import
import modelorder as mo
import lsq_generic as lg
os.chdir(_here)
mo.Problem, mo._best_complement, mo._exchange_from = lg.Problem, lg._best_complement, lg._exchange_from

D = np.load('eeg_inputs.npz')
X, G6, pos6, L7, pos7 = D['X'], D['G6'], D['pos6'], D['L7'], D['pos7']
FS = float(D['sfreq'])
mo.L, mo.GRID, mo.ALL = L7, pos7, np.arange(len(pos7))      # point the shared search code at the BEM grid
r, Ttot = X.shape
C_all = X @ X.T / Ttot
e, V = np.linalg.eigh(C_all); WALL = V @ np.diag(e ** -0.5) @ V.T
VIS = np.where(np.linalg.norm(WALL @ G6, axis=0) >= np.percentile(np.linalg.norm(WALL @ G6, axis=0), 30))[0]
SOS = butter(4, [5, 35], btype='band', fs=FS, output='sos')
TW = 2400


def pick_sources(Q, rng, min_sep=0.030):
    while True:
        idx = []
        for _ in range(200):
            j = int(rng.choice(VIS))
            if all(np.linalg.norm(pos6[j] - pos6[i]) >= min_sep for i in idx):
                idx.append(j)
            if len(idx) == Q:
                return idx


def simulate(Q, rho, snr, rng):
    idx = pick_sources(Q, rng)
    w = lambda: (lambda z: z / z.std())(sosfiltfilt(SOS, rng.standard_normal(TW + 600))[300:-300])
    common = w()
    S = np.array([np.sqrt(rho) * common + np.sqrt(1 - rho) * w() for _ in range(Q)])
    S *= rng.uniform(10, 25, Q)[:, None]
    sig = G6[:, idx] @ S
    t0 = int(rng.integers(0, Ttot - TW + 1))
    win = X[:, t0:t0 + TW]
    rest = np.concatenate([X[:, :t0], X[:, t0 + TW:]], axis=1)
    sig *= np.sqrt(snr * np.sum((WALL @ win) ** 2) / np.sum((WALL @ sig) ** 2))
    rest = rest - rest.mean(1, keepdims=True)
    eps = rest @ rest.T / rest.shape[1]
    return idx, win + sig, eps, rest.shape[1]


def ap_restarts(f, q, n, rng):
    S = f.ap(q); best = (f.prob.explained(S), S)
    for _ in range(n - 1):
        Sk = f.polish(list(rng.choice(len(pos7), q, replace=False))); e_ = f.prob.explained(Sk)
        if e_ > best[0]:
            best = (e_, Sk)
    return best[1]


if __name__ == '__main__':
    part, nparts, nrep = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    seed0 = int(sys.argv[4]) if len(sys.argv) > 4 else 700000
    cells = [(Q, rho, snr) for Q in (2, 3, 4) for rho in (1.0, 0.8, 0.3) for snr in (0.5, 2.0)]
    jobs = [(c, k) for c in cells for k in range(nrep)][part::nparts]
    for (Q, rho, snr), rep in jobs:
        seed = seed0 + 1000 * cells.index((Q, rho, snr)) + rep
        rng = np.random.default_rng(seed)
        idx, data, eps, Tn = simulate(Q, rho, snr, rng)
        pos = pos6[idx]
        f = mo.Fit(data, eps, Tn); r2 = np.random.default_rng(seed + 9)
        q = Q - 1
        out = dict(Q=Q, rho=rho, snr=snr, rep=rep, seed=seed, k=f.prob.k, res={})

        def rec(name, S, t0):
            S = sorted(int(s) for s in S)
            s10, s15 = mo.score(S, pos, 0.010), mo.score(S, pos, 0.015)
            Dm = np.linalg.norm(pos7[S][:, None] - pos[None], axis=2).min(1) * 1000
            out['res'][name] = dict(found=S, prec10=s10['precision'], rec10=s10['recall'], prec15=s15['precision'],
                                    rec15=s15['recall'], dist=float(Dm.mean()), expl=f.prob.explained(S),
                                    sec=time.time() - t0)
        t = time.time(); rec('AP', f.ap(q), t)
        t = time.time(); rec('AP6', ap_restarts(f, q, 6, r2), t)
        for extra in (1, 2):
            t = time.time(); rec(f'ESnp+{extra}', f.es_fixed(q, q + extra)[2], t)
        t = time.time(); rec('AP_exactQ', f.ap(Q), t)
        out['true_depth_mm'] = float(np.mean(np.linalg.norm(pos, axis=1)) * 1000)
        print(json.dumps(out), flush=True)
