"""Runtime table for the short EEG paper: Part B timings (be*/bl*.txt), re-timed TRAP-MUSIC / LCMV (rt_*.txt,
identical picks), and the post-hoc DCBF run on the Q = 2 EEG realisations (dcbf_eeg.txt)."""
import json, glob
import numpy as np

load = lambda pat: [json.loads(l) for f in sorted(glob.glob(pat)) for l in open(f) if l.strip()]
out = []
for name, pb, prt in (('EEG sample subject: 58 ch, 4,157 nodes x 3 orientations', 'be[0-9].txt', 'rt_be*.txt'),
                      ('User lead field: 70 ch, 3,554 nodes x 1 orientation', 'bl[0-9].txt', 'rt_bl*.txt')):
    R = load(pb); RT = {r['seed']: r for r in load(prt)}
    sec = lambda m, Q: np.array([(RT[r['seed']][m]['sec'] if m in ('TRAP', 'LCMV') else r['res'][m]['sec'])
                                 for r in R if r['Q'] == Q]) * 1000
    out.append(f'\n{name}  (median ms per realisation; Q = 2 / 3 / 4 true sources, Q-1 slots)')
    prep = np.array([r['prep_sec'] for r in R]) * 1000
    out.append(f'  {"shared preparation (whitening, subspace)":42s} {np.median(prep):6.0f}')
    for m, lab in (('AP', 'AP'), ('AP6', 'AP, 6 restarts'), ('ESnp+1', 'Extra slot +1'), ('ESnp+2', 'Extra slot +2'),
                   ('ESpol+1', 'Extra slot +1, re-fitted'), ('TRAP', 'TRAP-MUSIC'), ('LCMV', 'LCMV peaks'),
                   ('AP_exactQ', 'AP with the correct count Q')):
        out.append(f'  {lab:42s} ' + ' / '.join(f'{np.median(sec(m, Q)):6.0f}' for Q in (2, 3, 4)))

D = load('dcbf_eeg.txt')
if D:
    BE = {r['seed']: r for r in load('be[0-9].txt')}
    out.append(f'\nDCBF on the Q = 2 EEG realisations (n = {len(D)}; same data; DCBF and AP both given the correct count 2)')
    out.append(f'  {"method":34s} {"median s":>9s} {"IQR":>13s} {"prec@10":>8s} {"dist mm":>8s}')
    ap = [BE[d['seed']]['res']['AP_exactQ'] for d in D]
    out.append(f'  {"AP, 2 slots":34s} {np.median([a["sec"] for a in ap]):9.3f} {"":13s} '
               f'{np.mean([a["prec10"] for a in ap]):8.3f} {np.mean([a["dist"] for a in ap]):8.2f}')
    prep = np.median([d['prep_sec'] for d in D])
    for n in (10, 100, 1000):
        k = f'DCBF{n}'
        t = np.array([d['res'][k]['sec'] for d in D])
        out.append(f'  {"DCBF, " + str(n) + " Powell restarts":34s} {np.median(t):9.2f} '
                   f'{np.percentile(t, 25):6.2f}-{np.percentile(t, 75):<6.2f} {np.mean([d["res"][k]["prec10"] for d in D]):8.3f} '
                   f'{np.mean([d["res"][k]["dist"] for d in D]):8.2f}')
    out.append(f'  (DCBF preparation, C^-1 L etc.: median {prep * 1000:.0f} ms, not included above)')
    d = np.array([d_['res']['DCBF1000']['prec10'] for d_ in D]) - np.array([a['prec10'] for a in ap])
    rng = np.random.default_rng(0); bs = d[rng.integers(0, len(d), (4000, len(d)))].mean(1)
    out.append(f'  DCBF(1000) minus AP(2 slots), precision @10: {d.mean():+.3f} [{np.percentile(bs, 2.5):+.3f}, {np.percentile(bs, 97.5):+.3f}]')
print('\n'.join(out))
