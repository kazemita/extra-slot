"""Numerical check of equations (3)-(5): power explained by a true source, by the best single topography, and
their difference, for two sources with overlap c, correlation r and equal power s (20 000 random cases)."""
import numpy as np
rng = np.random.default_rng(5); bad = 0
for _ in range(20000):
    m = 20; a1 = rng.standard_normal(m); a1 /= np.linalg.norm(a1)
    a2 = rng.standard_normal(m) + rng.uniform(-3, 3) * a1; a2 /= np.linalg.norm(a2)
    c = a1 @ a2; r = rng.uniform(-1, 1); s = rng.uniform(0.5, 2)
    A = np.c_[a1, a2]; C = s * A @ np.array([[1, r], [r, 1]]) @ A.T
    lam = np.linalg.eigvalsh(C)[-1]
    pred = s * max((1 + c) * (1 + r), (1 - c) * (1 - r))
    gap = lam - s * (1 + c * c + 2 * r * c)
    predgap = s * (1 - c) * (c + r) if (c + r) >= 0 else s * (1 + c) * (-(c + r))
    bad += (abs(lam - pred) > 1e-9) or (abs(gap - predgap) > 1e-9)
print('formula check failures:', bad, 'of 20000')
