"""Build EEG hybrid-test inputs (see PREREGISTRATION_EEG.md) and cache them in eeg_inputs.npz.

* real EEG background: sample_audvis_trunc_raw.fif, good EEG channels, average reference (projector), 1-40 Hz
* EEG forward solutions computed here from the 3-layer BEM for the oct-6 cortical source space
  (simulation, fixed normal orientation) and the 7 mm volume grid (inversion, 3 orientations)
Everything is expressed in the r-dimensional range of the average-reference projector.
"""
import paths
import numpy as np
import mne

TD = paths.TD
raw = mne.io.read_raw_fif(TD + 'MEG/sample/sample_audvis_trunc_raw.fif', preload=True, verbose=False)
raw.pick('eeg', exclude='bads')
ch = raw.ch_names
P, nproj, _ = mne._fiff.proj.make_projector(raw.info['projs'], ch, bads=[])
raw.apply_proj(verbose=False)
raw.filter(1.0, 40.0, verbose=False)
X = raw.get_data()
ev, V = np.linalg.eigh((P + P.T) / 2)
Ur = V[:, ev > 0.5]
r = Ur.shape[1]

trans = TD + 'MEG/sample/sample_audvis_trunc-trans.fif'
bem = mne.read_bem_solution(TD + 'subjects/sample/bem/sample-1280-1280-1280-bem-sol.fif', verbose=False)
src6 = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', verbose=False)['src']
src7 = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-vol-7-fwd.fif', verbose=False)['src']
info = raw.info

f6 = mne.make_forward_solution(info, trans, src6, bem, meg=False, eeg=True, mindist=0.0, n_jobs=1, verbose=False)
f6 = mne.convert_forward_solution(f6, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
f7 = mne.make_forward_solution(info, trans, src7, bem, meg=False, eeg=True, mindist=0.0, n_jobs=1, verbose=False)
assert f6['sol']['row_names'] == ch and f7['sol']['row_names'] == ch

G6 = Ur.T @ (P @ f6['sol']['data']) * 1e-9            # r x n6, V per nAm, normal orientation
G7 = Ur.T @ (P @ f7['sol']['data']) * 1e-9            # r x 3*n7
n7 = f7['nsource']
L7 = G7.reshape(r, n7, 3).transpose(1, 0, 2).copy()   # (n7, r, 3): all three orientations kept
Xr = Ur.T @ X
np.savez('eeg_inputs.npz', X=Xr, sfreq=raw.info['sfreq'], G6=G6, pos6=f6['source_rr'], L7=L7,
         pos7=f7['source_rr'], ch=np.array(ch), rank=r)

# checks against the MEG test inputs: same vertices / grid nodes
M = np.load('hybrid_inputs.npz')
print(f'channels {len(ch)}, average-reference rank {r}, samples {Xr.shape[1]}, sim sources {G6.shape[1]}, '
      f'grid nodes {n7}')
print('same oct-6 vertices as MEG test:', np.allclose(f6['source_rr'], M['pos6']),
      '| same volume grid as MEG test:', np.allclose(f7['source_rr'], M['pos7']))
# the EEG rows of the testing-data forward should match our BEM forward closely if the same BEM was used
td6 = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', verbose=False)
td6 = mne.pick_channels_forward(td6, include=ch, ordered=True, verbose=False)
td6 = mne.convert_forward_solution(td6, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
a, b = P @ td6['sol']['data'], P @ mne.convert_forward_solution(f6, surf_ori=True, force_fixed=True, verbose=False)['sol']['data']
print('relative difference vs testing-data EEG forward: %.3f' % (np.linalg.norm(a - b) / np.linalg.norm(a)))
