"""Where the input data live. Set these environment variables, or edit the defaults.

MNE_TESTING_DATA  folder of the MNE testing dataset (contains MEG/sample/ and subjects/sample/bem/)
EEGLAB_SET        the EEGLAB tutorial recording eeglab_data.set (sccn/eeglab, sample_data/)
LEADFIELD_DIR     folder with Leadfield2.mat and voxelLocation2.mat (70-channel lead field; from the authors)
DS003775_EDF      sub-015_ses-t1_task-resteyesc_eeg.edf from OpenNeuro ds003775
"""
import os
ROOT = os.path.dirname(os.path.abspath(__file__))
CORE = os.path.join(ROOT, 'core')
TD = os.path.join(os.environ.get('MNE_TESTING_DATA', os.path.expanduser('~/mne_data/MNE-testing-data')), '')
EEGLAB_SET = os.environ.get('EEGLAB_SET', os.path.join(ROOT, 'data', 'eeglab_data.set'))
_LF = os.environ.get('LEADFIELD_DIR', os.path.join(ROOT, 'data', 'leadfield'))
LEADFIELD = os.path.join(_LF, 'Leadfield2.mat')
VOXELS = os.path.join(_LF, 'voxelLocation2.mat')
EDF = os.environ.get('DS003775_EDF', os.path.join(ROOT, 'data', 'sub-015_ses-t1_task-resteyesc_eeg.edf'))
