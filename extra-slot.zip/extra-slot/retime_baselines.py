"""Re-time TRAP-MUSIC and LCMV with the faster (mathematically identical) implementation in baselines.py and
check that they pick the same nodes as the first run (baselines_v1.py, stored in be*/bl*/hm*.txt).
usage: python3 retime_baselines.py SETTING PART NPARTS STOREDGLOB"""
import sys, json, time, glob
import numpy as np
import baselines as B
setting, part, nparts, pat = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
if setting == 'hme':
    import hme_run as S; simulate = lambda Q, rho, snr, rng, rep: S.simulate_k(rep % 6, Q, rho, snr, rng)
elif setting == 'eeg':
    import eeg_run as S; simulate = lambda Q, rho, snr, rng, rep: S.simulate(Q, rho, snr, rng)
else:
    import lf70_run as S; simulate = lambda Q, rho, snr, rng, rep: S.simulate(Q, rho, snr, rng)
mo = S.mo
R = sorted((json.loads(l) for f in sorted(glob.glob(pat)) for l in open(f)), key=lambda r: r['seed'])[part::nparts]
for r in R:
    rng = np.random.default_rng(r['seed'])
    idx, data, eps, Tn = simulate(r['Q'], r['rho'], r['snr'], rng, r['rep'])
    f = mo.Fit(data, eps, Tn); q = r['Q'] - 1
    out = dict(seed=r['seed'], Q=r['Q'])
    for name, fn in (('TRAP', lambda: B.trap_music(f, q)), ('LCMV', lambda: B.lcmv_peaks(f, q, mo.GRID))):
        t = time.perf_counter(); S_ = sorted(int(s) for s in fn()); dt = time.perf_counter() - t
        out[name] = dict(sec=dt, same=S_ == r['res'][name]['found'])
    print(json.dumps(out), flush=True)
