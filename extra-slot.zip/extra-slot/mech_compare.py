"""Noise-free diagnostics computable from the lead field + background covariance alone, for every setting:
 (a) single-source error: best single grid node for ONE source > 10 mm away (grid/orientation floor);
 (b) compromise rate: best single node for TWO sources (r = 1, 0.8) > 10 mm from both (as in mechanism.py M1).
usage: python3 mech_compare.py SETTING   (eeg | meg | lf70 | lf64r [LF64_MAP env])"""
import sys, json
import numpy as np
st = sys.argv[1]
if st in ('eeg', 'meg'):
    S = __import__('eeg_run' if st == 'eeg' else 'hybrid_run')
    Gs, Ps, Lg, Pg, W, VIS = S.G6, S.pos6, S.L7, S.pos7, S.WALL, S.VIS
    pick = S.pick_sources
else:
    S = __import__('lf70_run' if st == 'lf70' else 'lf64r_run')
    Gs, Ps, Lg, Pg = S.G, S.POS, S.mo.L, S.mo.GRID
    W = S.WALL if st == 'lf64r' else np.eye(S.G.shape[0])      # lf70: simulated noise ~ white after scaling
    VIS = S.VIS; pick = S.pick_sources
Aw = W @ Gs
U = np.linalg.svd(np.einsum('ab,pbo->pao', W, Lg), full_matrices=False)[0]
rng = np.random.default_rng(31)
single, comp = [], {1.0: [], 0.8: []}
for n in range(300):
    i, j = pick(2, rng)
    amp = rng.uniform(10, 25, 2)
    for k in (i,):
        e = np.sum(np.einsum('pmo,m->po', U, Aw[:, k]) ** 2, axis=1)
        single.append(np.linalg.norm(Pg[np.argmax(e)] - Ps[k]) * 1000)
    a = Aw[:, [i, j]]
    dn = np.linalg.norm(Pg[:, None] - Ps[[i, j]][None], axis=2).min(1) * 1000
    for r in (1.0, 0.8):
        Sig = np.diag(amp) @ np.array([[1, r], [r, 1]]) @ np.diag(amp)
        w_, V_ = np.linalg.eigh(Sig); M = a @ (V_ * np.sqrt(np.maximum(w_, 0)))
        e = np.sum(np.einsum('pmo,mk->pok', U, M) ** 2, axis=(1, 2))
        comp[r].append(dn[np.argmax(e)])
single, c1, c8 = np.array(single), np.array(comp[1.0]), np.array(comp[0.8])
lab = st + (':' + S.MAP if st == 'lf64r' else '')
print(json.dumps(dict(setting=lab, single_err_gt10=float(np.mean(single > 10)), single_med_mm=float(np.median(single)),
                      comp10_r1=float(np.mean(c1 > 10)), comp10_r08=float(np.mean(c8 > 10)),
                      comp15_r1=float(np.mean(c1 > 15)))))
