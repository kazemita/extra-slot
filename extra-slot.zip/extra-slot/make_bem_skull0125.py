"""Perturbed 'true' head model for Part A: the MNE sample 3-layer BEM (1280 triangles per surface) with skull
conductivity 0.0125 S/m (1:24) instead of 0.006 S/m (1:50). Built from the surfaces stored in the existing
BEM solution (avoids needing nibabel). -> sample-1280x3-skull0125-bem-sol.fif"""
import paths
import sys
import mne
TD = paths.TD
out = sys.argv[1] if len(sys.argv) > 1 else 'sample-1280x3-skull0125-bem-sol.fif'
bem0 = mne.read_bem_solution(TD + 'subjects/sample/bem/sample-1280-1280-1280-bem-sol.fif', verbose=False)
surfs = [dict(s) for s in bem0['surfs']]                      # inner skull, outer skull, scalp
for s, sigma in zip(surfs, (0.3, 0.0125, 0.3)):
    s['sigma'] = sigma
print([(s['id'], s['np'], s['sigma']) for s in surfs])
sol = mne.make_bem_solution(surfs, verbose=False)
mne.write_bem_solution(out, sol, overwrite=True, verbose=False)
