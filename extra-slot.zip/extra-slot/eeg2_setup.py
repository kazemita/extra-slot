"""Inputs for the independent EEG replication (PREREGISTRATION_EEG_REPLICATION.md) -> eeg2_inputs.npz.

Background: EEGLAB tutorial recording (30 scalp channels, 128 Hz, 238 s), standard 10-05 positions (fsaverage_1005),
average reference, 1-40 Hz. Head model: the MNE 'sample' subject's 3-layer BEM as a template (electrodes
projected onto its scalp by MNE). Same oct-6 cortical vertices (simulation) and 7 mm grid (inversion).
"""
import paths
import numpy as np
import mne

TD = paths.TD
raw = mne.io.read_raw_eeglab(paths.EEGLAB_SET, preload=True, verbose=False)
raw.set_channel_types({'EOG1': 'eog', 'EOG2': 'eog'}, verbose=False)
raw.pick('eeg')
mont = mne.channels.make_standard_montage('fsaverage_1005')
raw.set_montage(mont, match_case=False, on_missing='raise', verbose=False)
raw.set_eeg_reference('average', projection=True, verbose=False)
ch = raw.ch_names
P, nproj, _ = mne._fiff.proj.make_projector(raw.info['projs'], ch, bads=[])
raw.apply_proj(verbose=False)
raw.filter(1.0, 40.0, verbose=False)
X = raw.get_data()
ev, V = np.linalg.eigh((P + P.T) / 2)
Ur = V[:, ev > 0.5]; r = Ur.shape[1]

trans = TD + 'MEG/sample/sample_audvis_trunc-trans.fif'
bem = mne.read_bem_solution(TD + 'subjects/sample/bem/sample-1280-1280-1280-bem-sol.fif', verbose=False)
src6 = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', verbose=False)['src']
src7 = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-vol-7-fwd.fif', verbose=False)['src']
f6 = mne.make_forward_solution(raw.info, trans, src6, bem, meg=False, eeg=True, mindist=0.0, verbose=False)
f6 = mne.convert_forward_solution(f6, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
f7 = mne.make_forward_solution(raw.info, trans, src7, bem, meg=False, eeg=True, mindist=0.0, verbose=False)
assert f6['sol']['row_names'] == ch and f7['sol']['row_names'] == ch

G6 = Ur.T @ (P @ f6['sol']['data']) * 1e-9
G7 = Ur.T @ (P @ f7['sol']['data']) * 1e-9
n7 = f7['nsource']
L7 = G7.reshape(r, n7, 3).transpose(1, 0, 2).copy()
Xr = Ur.T @ X
np.savez('eeg2_inputs.npz', X=Xr, sfreq=raw.info['sfreq'], G6=G6, pos6=f6['source_rr'], L7=L7,
         pos7=f7['source_rr'], ch=np.array(ch), rank=r)

# placement check: distance from each standard electrode (head frame) to the template scalp
scalp = bem['surfs'][0]
head_mri = mne.read_trans(trans)
if head_mri['from'] != mne.io.constants.FIFF.FIFFV_COORD_HEAD:
    head_mri = mne.transforms.invert_transform(head_mri)
el = mne.transforms.apply_trans(head_mri, np.array([raw.info['chs'][i]['loc'][:3] for i in range(len(ch))]))
d = np.min(np.linalg.norm(el[:, None] - scalp['rr'][None], axis=2), axis=1) * 1000
M = np.load('eeg_inputs.npz')
print(f'channels {len(ch)}: {ch}')
print(f'rank {r}, samples {Xr.shape[1]} ({Xr.shape[1] / raw.info["sfreq"]:.0f} s), sfreq {raw.info["sfreq"]}')
print('same oct-6 vertices / grid as EEG test:', np.allclose(f6['source_rr'], M['pos6']), np.allclose(f7['source_rr'], M['pos7']))
print(f'electrode-to-scalp distance before projection (mm): median {np.median(d):.1f}, max {d.max():.1f}')
