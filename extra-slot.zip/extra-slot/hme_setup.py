"""Part A inputs: six perturbed 'true' EEG head models (skull 0.0125 S/m + co-registration error) for the
oct-6 cortical sources, in the same average-reference space as eeg_inputs.npz -> hme_inputs.npz."""
import paths
import numpy as np
import mne
from mne.transforms import rotation, translation, invert_transform, Transform

TD = paths.TD
raw = mne.io.read_raw_fif(TD + 'MEG/sample/sample_audvis_trunc_raw.fif', preload=False, verbose=False)
raw.pick('eeg', exclude='bads')
ch = raw.ch_names
P, _, _ = mne._fiff.proj.make_projector(raw.info['projs'], ch, bads=[])
ev, V = np.linalg.eigh((P + P.T) / 2); Ur = V[:, ev > 0.5]
E = np.load('eeg_inputs.npz')
assert list(E['ch']) == ch

trans0 = mne.read_trans(TD + 'MEG/sample/sample_audvis_trunc-trans.fif')
if trans0['from'] != mne.io.constants.FIFF.FIFFV_COORD_HEAD:
    trans0 = invert_transform(trans0)                        # head -> MRI
bem_true = mne.read_bem_solution('sample-1280x3-skull0125-bem-sol.fif', verbose=False)
src6 = mne.read_forward_solution(TD + 'MEG/sample/sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', verbose=False)['src']

rng = np.random.default_rng(4242)
G6s, perts = [], []
for k in range(6):
    ax = rng.standard_normal(3); ax /= np.linalg.norm(ax)
    ang = np.deg2rad(2.0)
    K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
    R = np.eye(4); R[:3, :3] = np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * K @ K
    d = rng.standard_normal(3); d *= 0.004 / np.linalg.norm(d)
    Tm = np.eye(4); Tm[:3, 3] = d
    pert = Tm @ R                                            # applied in the head frame
    trans_k = Transform('head', 'mri', trans0['trans'] @ pert)
    f = mne.make_forward_solution(raw.info, trans_k, src6, bem_true, meg=False, eeg=True, mindist=0.0, verbose=False)
    f = mne.convert_forward_solution(f, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
    assert f['sol']['row_names'] == ch
    # map kept sources back to the original oct-6 numbering; dropped vertices become NaN (unusable)
    full = np.full((Ur.shape[1], sum(len(s['vertno']) for s in src6)), np.nan)
    off0, off1 = 0, 0
    for s0, s1 in zip(src6, f['src']):
        pos_in = np.searchsorted(s0['vertno'], s1['vertno'])
        assert np.array_equal(s0['vertno'][pos_in], s1['vertno'])
        full[:, off0 + pos_in] = (Ur.T @ (P @ f['sol']['data'][:, off1:off1 + len(s1['vertno'])])) * 1e-9
        off0 += len(s0['vertno']); off1 += len(s1['vertno'])
    G6s.append(full)
    print(f'  model {k}: {np.isnan(full[0]).sum()} vertices dropped')
    perts.append(pert)
    ok = ~np.isnan(G6s[-1][0]); rel = np.linalg.norm(G6s[-1][:, ok] - E['G6'][:, ok]) / np.linalg.norm(E['G6'][:, ok])
    print(f'model {k}: axis {ax.round(2)}, shift {np.round(d * 1000, 1)} mm, '
          f'relative lead-field difference vs nominal {rel:.2f}')
np.savez('hme_inputs.npz', G6s=np.array(G6s), perts=np.array(perts))
