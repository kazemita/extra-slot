"""Re-run the pre-registered EEG realisations (same seeds, same data) with the rival methods of Sotudeh et al (2023)
(MUSIC, RAP-MUSIC, dipole fitting by downhill simplex, MV beamformer, sLORETA) next to AP, AP6, ESpol+1 and ES+1,
and record the 2023 measures: per-source localisation error (sources ranked by amplitude), misses, correlation
coefficient between reconstructed and true source signals, execution time. Descriptive, not pre-registered.

usage: python3 eval2023.py SETTING PART NPARTS [interf]
  SETTING: eeg | hme | lf70 | lf64r ;  'interf' adds a local interference (2023, section 4): the strongest
  source's contribution is added a second time to the three most anterior channels.
"""
import sys, json, time
import numpy as np
from scipy.optimize import linear_sum_assignment, minimize
from scipy.signal import sosfiltfilt
from scipy.spatial import cKDTree
import baselines as B
import paths

setting, part, nparts = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
interf = len(sys.argv) > 4 and sys.argv[4] == 'interf'
SEED0 = dict(eeg=700000, hme=1000000, lf70=900000, lf64r=1100000)[setting]
SNRS = (0.5, 2.0) if setting == 'eeg' else (2.0, 8.0)

# ----------------------------------------------------------------------------------- settings and simulators
if setting in ('eeg', 'hme'):
    import eeg_run as E
    mo = E.mo; POS_SRC = E.pos6
    if setting == 'hme':
        import hme_run as HM
    # physical-channel basis (same construction as eeg_setup.py) for the local interference
    import mne
    raw = mne.io.read_raw_fif(paths.TD + 'MEG/sample/sample_audvis_trunc_raw.fif', preload=False, verbose=False)
    raw.pick('eeg', exclude='bads')
    P, _, _ = mne._fiff.proj.make_projector(raw.info['projs'], raw.ch_names, bads=[])
    ev, V = np.linalg.eigh((P + P.T) / 2); UR = V[:, ev > 0.5]
    chpos = np.array([c['loc'][:3] for c in raw.info['chs']])
    FRONT = list(np.argsort(-chpos[:, 1])[:3])                         # three most anterior electrodes

    def simulate(Q, rho, snr, rng, rep):
        """copy of eeg_run.simulate that also returns the source waveforms and the strongest source's signal"""
        if setting == 'hme':
            k = rep % 6; valid = ~np.isnan(HM.G6S[k][0])
            E.G6 = np.where(np.isnan(HM.G6S[k]), 0.0, HM.G6S[k]); E.VIS = HM.VIS_NOMINAL[valid[HM.VIS_NOMINAL]]
        try:
            idx = E.pick_sources(Q, rng)
            w = lambda: (lambda z: z / z.std())(sosfiltfilt(E.SOS, rng.standard_normal(E.TW + 600))[300:-300])
            common = w()
            S = np.array([np.sqrt(rho) * common + np.sqrt(1 - rho) * w() for _ in range(Q)])
            S *= rng.uniform(10, 25, Q)[:, None]
            parts = [E.G6[:, [j]] @ S[[i]] for i, j in enumerate(idx)]
            sig = sum(parts)
            t0 = int(rng.integers(0, E.Ttot - E.TW + 1))
            win = E.X[:, t0:t0 + E.TW]
            rest = np.concatenate([E.X[:, :t0], E.X[:, t0 + E.TW:]], axis=1)
            scale = np.sqrt(snr * np.sum((E.WALL @ win) ** 2) / np.sum((E.WALL @ sig) ** 2))
            sig *= scale
            rest = rest - rest.mean(1, keepdims=True)
            data = win + sig
            extra = None
            if interf:
                i1 = int(np.argmax(np.abs(S).std(1)))
                phys = UR @ (parts[i1] * scale)                            # strongest source on the channels
                e = np.zeros_like(phys); e[FRONT] = phys[FRONT]
                extra = UR.T @ e
            return idx, data, rest @ rest.T / rest.shape[1], rest.shape[1], S, extra
        finally:
            if setting == 'hme':
                E.G6, E.VIS = HM.G6_NOMINAL, HM.VIS_NOMINAL
    ap_restarts = E.ap_restarts
else:
    S_ = __import__('lf70_run' if setting == 'lf70' else 'lf64r_run')
    mo = S_.mo; POS_SRC = S_.POS
    if setting == 'lf64r':
        import mne
        FRONT = [0, 32, 33]                                                # Fp1, Fpz, Fp2 (EDF order)
    else:
        FRONT = None

    def simulate(Q, rho, snr, rng, rep):
        """copies of lf70_run.simulate / lf64r_run.simulate that also return the source waveforms"""
        G = S_.G
        idx = S_.pick_sources(Q, rng)
        w = lambda: (lambda z: z / z.std())(sosfiltfilt(S_.SOS, rng.standard_normal(S_.TW + 600))[300:-300])
        common = w()
        S = np.array([np.sqrt(rho) * common + np.sqrt(1 - rho) * w() for _ in range(Q)]) * rng.uniform(10, 25, Q)[:, None]
        parts = [G[:, [j]] @ S[[i]] for i, j in enumerate(idx)]
        sig = sum(parts)
        if setting == 'lf70':
            n_bg = 2000; TW, TN, r = S_.TW, S_.TN, S_.r
            bg_idx = rng.choice(G.shape[1], n_bg, replace=False); Gb = G[:, bg_idx]

            def brain(T):
                z = sosfiltfilt(S_.SOS_BG, np.cumsum(rng.standard_normal((n_bg, T + 600)), axis=1), axis=1)[:, 300:-300]
                return Gb @ (z / z.std(axis=1, keepdims=True))
            bw, bb = brain(TW), brain(TN)
            sc = np.sqrt(r / np.sum(bw ** 2) * TW)
            back = sc * bw + rng.standard_normal((r, TW)); base = sc * bb + rng.standard_normal((r, TN))
            scale = np.sqrt(snr * np.sum(back ** 2) / np.sum(sig ** 2)); sig *= scale
            base -= base.mean(1, keepdims=True)
            return idx, back + sig, base @ base.T / TN, TN, S, None
        t0 = int(rng.integers(0, S_.Ttot - S_.TW + 1))
        win = S_.X[:, t0:t0 + S_.TW]
        rest = np.concatenate([S_.X[:, :t0], S_.X[:, t0 + S_.TW:]], axis=1)
        scale = np.sqrt(snr * np.sum((S_.WALL @ win) ** 2) / np.sum((S_.WALL @ sig) ** 2)); sig *= scale
        rest = rest - rest.mean(1, keepdims=True)
        extra = None
        if interf:
            i1 = int(np.argmax(np.abs(S).std(1)))
            phys = S_.Ur @ (parts[i1] * scale); e = np.zeros_like(phys); e[FRONT] = phys[FRONT]
            extra = S_.Ur.T @ S_.H @ e
        return idx, win + sig, rest @ rest.T / rest.shape[1], rest.shape[1], S, extra
    ap_restarts = S_.ap_restarts

GRID = mo.GRID
TREE = cKDTree(GRID)


# ----------------------------------------------------------------------------------- rival methods
def peaks(score, q, min_sep=0.020):
    picked = []
    for j in np.argsort(-score):
        if all(np.linalg.norm(GRID[j] - GRID[i]) >= min_sep for i in picked):
            picked.append(int(j))
        if len(picked) == q:
            break
    return picked


def music(f, q):
    """MUSIC pseudo-spectrum (signal subspace of dimension q, optimal orientation); q highest peaks >= 20 mm apart"""
    Lw = f.prob.Lw
    lam, V = np.linalg.eigh(f.Cw); Us = V[:, ::-1][:, :q]
    Gram = Lw.transpose(0, 2, 1) @ Lw
    Gram = Gram + 1e-12 * np.mean(np.trace(Gram, axis1=1, axis2=2)) * np.eye(Lw.shape[2])   # scale-free ridge
    cross = Lw.transpose(0, 2, 1) @ Us
    sc, _ = B._gen_eig_max(cross @ cross.transpose(0, 2, 1), Gram)
    return peaks(sc, q)


def rap_music(f, q):
    """RAP-MUSIC (Mosher and Leahy 1999): recursive projection, full (untruncated) subspace"""
    Lw = f.prob.Lw; p, m, no = Lw.shape
    lam, V = np.linalg.eigh(f.Cw); Us = V[:, ::-1][:, :q]
    picked, topo = [], []
    for k in range(q):
        if topo:
            A = np.array(topo).T; Qk = np.eye(m) - A @ np.linalg.pinv(A)
            Usk = np.linalg.svd(Qk @ Us, full_matrices=False)[0][:, :q]
        else:
            Qk = np.eye(m); Usk = Us
        Bm = Qk @ Lw; Bt = Bm.transpose(0, 2, 1)
        Gm = Bt @ Bm; Gm = Gm + 1e-12 * np.mean(np.trace(Lw.transpose(0, 2, 1) @ Lw, axis1=1, axis2=2)) * np.eye(no)
        sc, eta = B._gen_eig_max(Bt @ Usk @ (Bt @ Usk).transpose(0, 2, 1), Gm)
        sc[picked] = -np.inf
        j = int(np.argmax(sc)); picked.append(j); topo.append(Lw[j] @ eta[j])
    return picked


def sloreta_op(f):
    """sLORETA (Pascual-Marqui 2002) on whitened data, regularisation lambda2 = 1/9 (SNR 3)"""
    Lw = f.prob.Lw; p, m, no = Lw.shape
    Lf = Lw.transpose(1, 0, 2).reshape(m, p * no)
    K = Lf @ Lf.T
    Ci = np.linalg.inv(K + (np.trace(K) / m) / 9.0 * np.eye(m))
    T = (Lf.T @ Ci).reshape(p, no, m)                                     # p x no x m
    R = T @ Lw                                                            # resolution blocks p x no x no
    return T, R


def sloreta(f, q):
    T, R = sloreta_op(f)
    TC = T @ f.Cw @ T.transpose(0, 2, 1)
    sc = np.einsum('pij,pji->p', np.linalg.inv(R), TC)                    # standardised power
    return peaks(sc, q), T, R


def dipole_fit(f, q, rng, maxiter=None):
    """dipole fitting by downhill simplex (Nelder-Mead) over continuous positions, lead fields of the nearest
    grid node, objective = signal power left unexplained; one start from q random grid nodes"""
    def nodes(x):
        return [int(TREE.query(x[3 * i:3 * i + 3])[1]) for i in range(q)]

    def obj(x):
        S = nodes(x)
        if len(set(S)) < q:
            return 1e6
        return -f.prob.explained(S)
    x0 = GRID[rng.choice(len(GRID), q, replace=False)].ravel()
    simplex = np.vstack([x0] + [x0 + 0.015 * np.eye(3 * q)[i] for i in range(3 * q)])   # 15 mm steps (> grid spacing)
    res = minimize(obj, x0, method='Nelder-Mead', options=dict(maxiter=maxiter or 200 * 3 * q, xatol=1e-3, fatol=0.0,
                                                               initial_simplex=simplex))
    return nodes(res.x)


def mv(f, q):
    picked = B.lcmv_peaks(f, q, GRID)
    return picked


# ----------------------------------------------------------------------------------- signal read-out
def dominant(ts):
    """no x T orientation time courses -> single time course along the dominant direction"""
    if ts.shape[0] == 1:
        return ts[0]
    u = np.linalg.svd(ts, full_matrices=False)[0][:, 0]
    return u @ ts


def readout_ls(f, S):
    Lw = f.prob.Lw; no = Lw.shape[2]
    A = np.concatenate([Lw[j] for j in S], axis=1)
    J = np.linalg.lstsq(A, f.prob.Bw, rcond=None)[0]
    return [dominant(J[k * no:(k + 1) * no]) for k in range(len(S))]


def readout_mv(f, S, reg=0.05):
    m = f.Cw.shape[0]
    C = f.Cw + reg * np.trace(f.Cw) / m * np.eye(m); Ci = np.linalg.inv(C)
    out = []
    for j in S:
        L = f.prob.Lw[j]; W = Ci @ L @ np.linalg.inv(L.T @ Ci @ L)
        out.append(dominant(W.T @ f.prob.Bw))
    return out


def readout_sl(f, S, T):
    return [dominant(T[j] @ f.prob.Bw) for j in S]


# ----------------------------------------------------------------------------------- measures
def measure(S, idx, S_true, ts):
    """per true source (ranked by amplitude, 1 = strongest): error (m) if matched, else None; |C| if matched"""
    pos = POS_SRC[idx]; Q = len(idx)
    rank = np.argsort(-S_true.std(1))                                     # rank[0] = index of the strongest
    D = np.linalg.norm(pos[:, None] - GRID[S][None], axis=2)              # true x found
    r, c = linear_sum_assignment(D)
    err = [None] * Q; corr = [None] * Q
    for ti, fi in zip(r, c):
        k = int(np.where(rank == ti)[0][0])
        err[k] = float(D[ti, fi])
        if ts is not None:
            a, b = ts[fi], S_true[ti]
            corr[k] = float(abs(np.corrcoef(a, b)[0, 1]))
    return err, corr


cells = [(Q, rho, snr) for Q in (2, 3, 4) for rho in (1.0, 0.8, 0.3) for snr in SNRS]
jobs = [(c, k) for c in cells for k in range(15)][part::nparts]
for (Q, rho, snr), rep in jobs:
    seed = SEED0 + 1000 * cells.index((Q, rho, snr)) + rep
    rng = np.random.default_rng(seed)
    idx, data, eps, Tn, S_true, extra = simulate(Q, rho, snr, rng, rep)
    if extra is not None:
        data = data + extra
    t = time.perf_counter(); f = mo.Fit(data, eps, Tn); prep = time.perf_counter() - t
    q = Q - 1; r2 = np.random.default_rng(seed + 9); r3 = np.random.default_rng(seed + 23)
    out = dict(setting=setting, interf=interf, Q=Q, rho=rho, snr=snr, rep=rep, seed=seed, prep_sec=prep, res={})
    for name in ('MUSIC', 'RAP-MUSIC', 'Dipole fit', 'MV', 'sLORETA', 'AP', 'AP6', 'ESpol+1', 'ES+1'):
        t = time.perf_counter()
        if name == 'MUSIC': S = music(f, q)
        elif name == 'RAP-MUSIC': S = rap_music(f, q)
        elif name == 'Dipole fit': S = dipole_fit(f, q, r3)
        elif name == 'MV': S = mv(f, q)
        elif name == 'sLORETA': S, Tsl, Rsl = sloreta(f, q)
        elif name == 'AP': S = f.ap(q)
        elif name == 'AP6': S = ap_restarts(f, q, 6, r2)
        elif name == 'ESpol+1': S = f.es_fixed(q, q + 1)[0]
        elif name == 'ES+1': S = f.es_fixed(q, q + 1)[2]
        sec = time.perf_counter() - t
        S = [int(s) for s in S]
        ts = readout_mv(f, S) if name == 'MV' else readout_sl(f, S, Tsl) if name == 'sLORETA' else readout_ls(f, S)
        err, corr = measure(S, idx, S_true, ts)
        out['res'][name] = dict(found=sorted(S), err=err, corr=corr, sec=sec)
    print(json.dumps(out), flush=True)
