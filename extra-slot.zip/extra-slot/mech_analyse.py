"""Step 3 summary: noise-free compromise positions, MEG vs EEG (mech_meg.txt, mech_eeg.txt)."""
import json
import numpy as np

D = {m: [json.loads(l) for l in open(f'mech_{m}.txt')] for m in ('meg', 'eeg')}
print('M1  exhaustive noise-free single-node fit to TWO sources (q = 1, Q = 2), 400 pairs >= 30 mm apart')
print('    "compromise" = best single node > 15 mm from both true sources\n')
for m in ('meg', 'eeg'):
    M1 = [d for d in D[m] if d['part'] == 'M1']
    for r in (1.0, 0.8, 0.3):
        X = [d for d in M1 if d['r'] == r]
        comp = np.array([d['best_dist_mm'] > 15 for d in X]); dist = np.array([d['best_dist_mm'] for d in X])
        gain = np.array([d['gain_vs_near'] for d in X])
        print(f'  {m.upper()} r={r}: compromise {comp.mean():.2f}; median distance of best node {np.median(dist):5.1f} mm; '
              f'compromises explain {np.median(gain[comp]) * 100 - 100 if comp.any() else 0:4.1f}% more power than the best node at a true source (median)')
    X = [d for d in M1 if d['r'] == 1.0]
    c = np.array([d['c'] for d in X]); sep = np.array([d['sep_mm'] for d in X])
    print(f'  {m.upper()} topographic overlap |c| of the two sources by separation (median [IQR]):')
    for lo, hi in ((30, 50), (50, 70), (70, 100), (100, 200)):
        k = (sep >= lo) & (sep < hi)
        print(f'      {lo:3d}-{hi:3d} mm (n={k.sum():3d}): {np.median(c[k]):.2f} [{np.percentile(c[k], 25):.2f}, {np.percentile(c[k], 75):.2f}]')
    mim = np.array([d['mimic_max'] for d in X])
    print(f'  {m.upper()} how well the best single node can mimic the sum topography (max_g ||P_g v||^2, r=1): '
          f'median {np.median(mim):.2f} [IQR {np.percentile(mim, 25):.2f}-{np.percentile(mim, 75):.2f}]')
    comp = np.array([d['best_dist_mm'] > 15 for d in X])
    print(f'  {m.upper()} compromise rate (r=1) by separation: ' + ', '.join(
        f'{lo}-{hi} mm {np.mean(comp[(sep >= lo) & (sep < hi)]):.2f}' for lo, hi in ((30, 50), (50, 70), (70, 100), (100, 200))))
    ar = np.array([d['amp_ratio'] for d in X])
    print(f'  {m.upper()} compromise rate (r=1) by amplitude ratio: ' + ', '.join(
        f'{lo}-{hi} {np.mean(comp[(ar >= lo) & (ar < hi)]):.2f}' for lo, hi in ((0.4, 0.6), (0.6, 0.8), (0.8, 1.01))))
    print()

print('M2  full pipeline, SNR = 1000 (essentially noise-free), Q-1 slots, 30 realisations per cell; precision @10 mm')
for m in ('meg', 'eeg'):
    M2 = [d for d in D[m] if d['part'] == 'M2']
    for Q in (2, 3):
        for r in (1.0, 0.8, 0.3):
            X = [d for d in M2 if d['Q'] == Q and d['r'] == r]
            v = {k: np.mean([d['res'][k]['prec10'] for d in X]) for k in ('AP', 'AP6', 'ESnp+1', 'AP_exactQ')}
            ex = np.mean([d['res']['AP6']['expl'] >= d['res']['ESnp+1']['expl'] - 1e-9 for d in X])
            print(f'  {m.upper()} Q={Q} r={r}: AP {v["AP"]:.2f}  AP6 {v["AP6"]:.2f}  ES+1 {v["ESnp+1"]:.2f}  '
                  f'(AP, correct count {v["AP_exactQ"]:.2f}); AP6 explains >= ES+1: {ex:.2f}')
    X = M2
    print(f'  {m.upper()} pooled: AP6 {np.mean([d["res"]["AP6"]["prec10"] for d in X]):.3f}, '
          f'ES+1 {np.mean([d["res"]["ESnp+1"]["prec10"] for d in X]):.3f}\n')
