"""Tables in the format of Sotudeh et al (2023), Tables 2, 3, 5, 6 and 7, from v23_*.txt / v23i_*.txt.
Sources are ranked by amplitude within each realisation (1 = strongest). RMSE_k = sqrt(mean squared error of
source k over the runs in which it was matched to a reported location); a source is 'missed' when no reported
location is assigned to it (one-to-one matching, minimum total distance)."""
import json, glob
import numpy as np

SET = [('eeg', 'EEG, sample subject'), ('hme', 'EEG, head-model error'), ('lf70', '70-ch lead field, simulated bg'),
       ('lf64r', '64-ch lead field, real bg')]
METH = ['MUSIC', 'RAP-MUSIC', 'Dipole fit', 'MV', 'sLORETA', 'AP', 'AP6', 'ESpol+1', 'ES+1']
load = lambda p: [json.loads(l) for f in sorted(glob.glob(p)) for l in open(f) if l.strip()]
db = lambda s: f'{10 * np.log10(s):+.0f}'
D = {s: load(f'v23_{s}_[0-9].txt') for s, _ in SET}
DI = {s: load(f'v23i_{s}_[0-9].txt') for s in ('eeg', 'lf64r')}


def rmse(R, m, k):
    e = [r['res'][m]['err'][k] for r in R if len(r['res'][m]['err']) > k and r['res'][m]['err'][k] is not None]
    return np.sqrt(np.mean(np.square(e))) if e else np.nan


def miss(R, m, k):
    v = [r['res'][m]['err'][k] is None for r in R if len(r['res'][m]['err']) > k]
    return 100 * np.mean(v)


def corr(R, m, k):
    c = [r['res'][m]['corr'][k] for r in R if len(r['res'][m]['corr']) > k and r['res'][m]['corr'][k] is not None]
    return np.mean(c)


out = {}
print('TABLE A (cf. 2023 Table 2): RMSE (m) of the strongest / second / third source; columns: setting x SBR (dB)')
hdr = [f'{s}@{db(snr)}' for s, _ in SET for snr in sorted(set(r['snr'] for r in D[s]))]
print(' ' * 14 + ''.join(f'{h:>11s}' for h in hdr))
out['A'] = {}
for m in METH:
    for k in range(3):
        row = []
        for s, _ in SET:
            for snr in sorted(set(r['snr'] for r in D[s])):
                row.append(rmse([r for r in D[s] if r['snr'] == snr], m, k))
        out['A'][f'{m}|{k}'] = row
        print(f'{(m if k == 0 else ""):11s} {k + 1} ' + ''.join(f'{v:11.4f}' for v in row))

print('\nTABLE B: missed sources (%) by rank (all settings pooled) and overall per setting')
out['B'] = {}
for m in METH:
    allR = [r for s, _ in SET for r in D[s]]
    row = [miss(allR, m, k) for k in range(3)] + [np.mean([e is None for r in D[s] for e in r['res'][m]['err']]) * 100 for s, _ in SET]
    out['B'][m] = row
    print(f'{m:11s} ' + ''.join(f'{v:8.1f}' for v in row))

print('\nTABLE C (cf. 2023 Table 3): mean |C| of reconstructed vs true signal, sources 1-3; all four settings')
out['C'] = {}
for m in METH:
    row = [corr(D[s], m, k) for s, _ in SET for k in range(3)]
    out['C'][m] = row
    print(f'{m:11s} ' + ''.join(f'{v:7.3f}' for v in row))

print('\nTABLE D (cf. 2023 Table 5): RMSE (m) with local interference [without], sources 1-3')
out['D'] = {}
for m in METH:
    row = []
    for s in ('eeg', 'lf64r'):
        row += [rmse(DI[s], m, k) for k in range(3)]
    rowo = []
    for s in ('eeg', 'lf64r'):
        rowo += [rmse(D[s], m, k) for k in range(3)]
    out['D'][m] = (row, rowo)
    print(f'{m:11s} ' + ''.join(f'{v:8.4f}[{w:.4f}]' for v, w in zip(row, rowo)))

print('\nTABLE E (cf. 2023 Table 6): mean |C| with local interference [without]')
out['E'] = {}
for m in METH:
    row = []; rowo = []
    for s in ('eeg', 'lf64r'):
        row += [corr(DI[s], m, k) for k in range(3)]; rowo += [corr(D[s], m, k) for k in range(3)]
    out['E'][m] = (row, rowo)
    print(f'{m:11s} ' + ''.join(f'{v:7.3f}[{w:.3f}]' for v, w in zip(row, rowo)))

print('\nTABLE F (cf. 2023 Table 7): mean execution time (s) per localisation; + shared preparation')
out['F'] = {}
for s, lab in SET:
    row = [np.mean([r['res'][m]['sec'] for r in D[s]]) for m in METH]
    prep = np.mean([r['prep_sec'] for r in D[s]])
    out['F'][s] = (row, prep)
    print(f'{s:6s} ' + ''.join(f'{v:8.3f}' for v in row) + f'   prep {prep:.3f}')
print('n per setting:', {s: len(D[s]) for s, _ in SET}, 'interf:', {s: len(DI[s]) for s in DI})

# overall localisation error (all matched sources) and paired comparison ES+1 vs AP6
print('\nOverall RMSE (all matched sources), per setting:')
for s, _ in SET:
    print(s, ' '.join(f'{m} {np.sqrt(np.mean([e**2 for r in D[s] for e in r["res"][m]["err"] if e is not None])):.4f}' for m in METH))
json.dump(out, open('tables2023.json', 'w'), default=float)
