"""Summary of the real-background test and its two descriptive arms (lr*, lrA*, lrB* outputs)."""
import json, glob, numpy as np
def load(p): return [json.loads(l) for f in sorted(glob.glob(p)) for l in open(f)]
def boot(d, n=4000):
    rng = np.random.default_rng(0); m = d[rng.integers(0, len(d), (n, len(d)))].mean(1); return d.mean(), np.percentile(m, 2.5), np.percentile(m, 97.5)
M = ['AP', 'AP6', 'ESnp+1', 'ESnp+2', 'ESpol+1', 'TRAP', 'LCMV', 'AP_exactQ']
for lab, p in (('PRIMARY (reconstructed order)', 'lr[0-9].txt'), ('Arm A: Main.m mapping (rows 1-64)', 'lrA[0-9].txt'), ('Arm B: unrefined reconstructed order', 'lrB[0-9].txt')):
    R = load(p)
    print(f'\n{lab}: n={len(R)}')
    print('  prec@10: ' + '  '.join(f'{m} {np.mean([r["res"][m]["prec10"] for r in R]):.3f}' for m in M))
    print('  prec@15 AP(Q) validity: %.3f' % np.mean([r['res']['AP_exactQ']['prec15'] for r in R]))
    for m in ('AP6', 'AP', 'ESpol+1', 'TRAP', 'LCMV'):
        d = np.array([r['res']['ESnp+1']['prec10'] - r['res'][m]['prec10'] for r in R]); mu, lo, hi = boot(d)
        print(f'  ES+1 - {m:8s} {mu:+.3f} [{lo:+.3f}, {hi:+.3f}]')
    d = np.array([r['res']['ESnp+2']['prec10'] - r['res']['AP6']['prec10'] for r in R]); mu, lo, hi = boot(d)
    print(f'  ES+2 - AP6      {mu:+.3f} [{lo:+.3f}, {hi:+.3f}]')
    print('  by Q, AP6 / ES+1 / ES+2 / AP(Q): ' + ' | '.join(
        f'Q={Q}: ' + '/'.join(f'{np.mean([r["res"][m]["prec10"] for r in R if r["Q"] == Q]):.2f}' for m in ('AP6', 'ESnp+1', 'ESnp+2', 'AP_exactQ')) for Q in (2, 3, 4)))
    print('  signal-subspace dimension k (median by Q): ' + ', '.join(f'Q={Q}: {np.median([r["k"] for r in R if r["Q"] == Q]):.0f}' for Q in (2, 3, 4)))
