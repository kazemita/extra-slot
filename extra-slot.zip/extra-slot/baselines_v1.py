"""Baseline localisers for Part B (PREREGISTRATION_STEP12.md), on a modelorder.Fit object (whitened data,
whitened lead fields f.prob.Lw of shape (nodes, channels, orientations))."""
import numpy as np


def _gen_eig_max(Amat, Bmat):
    """largest generalised eigenvalue / eigenvector of (A, B) for a batch of small matrices"""
    M = np.linalg.solve(Bmat, Amat)
    w, V = np.linalg.eig(M)
    i = np.argmax(w.real, axis=1)
    lam = w.real[np.arange(len(w)), i]
    vec = V.real[np.arange(len(w)), :, i]
    return lam, vec


def trap_music(f, q):
    """TRAP-MUSIC (Makela et al., 2018) with signal-subspace dimension q, vector lead fields."""
    Lw = f.prob.Lw                                   # (p, m, no)
    p, m, no = Lw.shape
    lam, V = np.linalg.eigh(f.Cw)
    Us = V[:, ::-1][:, :q]
    picked, topo = [], []
    for k in range(q):
        if topo:
            A = np.array(topo).T
            Qk = np.eye(m) - A @ np.linalg.pinv(A)
            U, s, _ = np.linalg.svd(Qk @ Us, full_matrices=False)
            Usk = U[:, :q - k]
        else:
            Qk = np.eye(m); Usk = Us
        B = np.einsum('ab,pbo->pao', Qk, Lw)
        Gram = np.einsum('pao,pai->poi', B, B) + 1e-12 * np.eye(no)
        cross = np.einsum('pao,ad->pod', B, Usk)
        score, eta = _gen_eig_max(cross @ cross.transpose(0, 2, 1), Gram)
        score[picked] = -np.inf
        j = int(np.argmax(score))
        picked.append(j)
        topo.append(Lw[j] @ eta[j])
    return picked


def lcmv_peaks(f, q, grid_pos, min_sep=0.020, reg=0.05):
    """Unit-noise-gain vector LCMV (neural activity index, optimal orientation); q highest nodes >= min_sep apart."""
    Lw = f.prob.Lw
    p, m, no = Lw.shape
    C = f.Cw + reg * np.mean(np.linalg.eigvalsh(f.Cw)) * np.eye(m)
    Ci = np.linalg.inv(C)
    CiL = np.einsum('ab,pbo->pao', Ci, Lw)
    A = np.einsum('pao,pai->poi', Lw, CiL)
    Bm = np.einsum('pao,pai->poi', CiL, CiL)
    nai, _ = _gen_eig_max(A, Bm)
    picked = []
    for j in np.argsort(-nai):
        if all(np.linalg.norm(grid_pos[j] - grid_pos[i]) >= min_sep for i in picked):
            picked.append(int(j))
        if len(picked) == q:
            break
    return picked
