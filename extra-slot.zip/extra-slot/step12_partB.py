"""Part B (PREREGISTRATION_STEP12.md): baselines and runtime, descriptive.
Also checks that the re-runs reproduce the stored EEG / 70-channel test results exactly (same seeds)."""
import json, glob
import numpy as np

SETS = [('EEG, sample subject (real background)', 'be[0-9].txt', 'ee[0-9].txt'),
        ('70-ch lead field (simulated brain noise)', 'bl[0-9].txt', 'lf[0-9].txt'),
        ('EEG + head-model error (Part A)', 'hm[0-9].txt', None)]
METHODS = ['AP', 'AP6', 'ESnp+1', 'ESnp+2', 'ESpol+1', 'TRAP', 'LCMV']
LABEL = {'AP': 'AP', 'AP6': 'AP, 6 restarts', 'ESnp+1': 'Extra slot +1', 'ESnp+2': 'Extra slot +2',
         'ESpol+1': 'Extra slot +1, re-fitted', 'TRAP': 'TRAP-MUSIC', 'LCMV': 'LCMV peaks'}


def load(pat):
    return [json.loads(l) for f in sorted(glob.glob(pat)) for l in open(f) if l.strip()]


def boot(d, n=4000, seed=0):
    rng = np.random.default_rng(seed)
    m = d[rng.integers(0, len(d), (n, len(d)))].mean(1)
    return d.mean(), np.percentile(m, 2.5), np.percentile(m, 97.5)


summary = {}
for name, pat, old in SETS:
    R = load(pat)
    print(f'\n=== {name}: {len(R)} realisations ===')
    if old:
        O = {o['seed']: o for o in load(old)}
        same = sum(all(O[r['seed']]['res'][m]['found'] == r['res'][m]['found']
                       for m in ('AP', 'AP6', 'ESnp+1', 'ESnp+2', 'AP_exactQ')) for r in R)
        print(f'reproduces stored test results (found locations, 5 methods): {same}/{len(R)}')
    print(f'{"method":28s} {"prec@10":>8s} {"prec@15":>8s} {"dist mm":>8s}   ES+1 minus method, prec@10 [95% CI]')
    s = {}
    for m in METHODS:
        p10 = np.array([r['res'][m]['prec10'] for r in R]); p15 = np.array([r['res'][m]['prec15'] for r in R])
        dist = np.array([r['res'][m]['dist'] for r in R])
        d = np.array([r['res']['ESnp+1']['prec10'] for r in R]) - p10
        mu, lo, hi = boot(d)
        s[m] = dict(p10=p10.mean(), p15=p15.mean(), dist=dist.mean(), diff=(mu, lo, hi))
        txt = '' if m == 'ESnp+1' else f'{mu:+.3f} [{lo:+.3f}, {hi:+.3f}]'
        print(f'{LABEL[m]:28s} {p10.mean():8.3f} {p15.mean():8.3f} {dist.mean():8.2f}   {txt}')
    # runtime
    prep = np.array([r['prep_sec'] for r in R]) * 1000
    print(f'\nruntime per realisation (ms, single BLAS thread); shared preparation (whitening, subspace): '
          f'median {np.median(prep):.0f} [IQR {np.percentile(prep, 25):.0f}-{np.percentile(prep, 75):.0f}]')
    print(f'{"method":28s} {"median":>8s} {"IQR":>13s} {"mean":>8s} {"x AP":>6s}   median by Q=2/3/4')
    tAP = np.median([r['res']['AP']['sec'] for r in R])
    for m in METHODS:
        t = np.array([r['res'][m]['sec'] for r in R]) * 1000
        byq = '/'.join(f'{np.median([r["res"][m]["sec"] for r in R if r["Q"] == Q]) * 1000:.0f}' for Q in (2, 3, 4))
        s[m]['t_med'] = np.median(t); s[m]['t_iqr'] = (np.percentile(t, 25), np.percentile(t, 75))
        print(f'{LABEL[m]:28s} {np.median(t):8.0f} {np.percentile(t, 25):6.0f}-{np.percentile(t, 75):<6.0f} '
              f'{t.mean():8.0f} {np.median(t) / 1000 / tAP:6.1f}   {byq}')
    s['prep'] = (np.median(prep), np.percentile(prep, 25), np.percentile(prep, 75))
    summary[name] = s
    # where do the gains come from
    print('\nprec@10 by Q (AP6 / ES+1 / TRAP / LCMV / AP with correct count):')
    for Q in (2, 3, 4):
        RQ = [r for r in R if r['Q'] == Q]
        vals = [np.mean([r['res'][m]['prec10'] for r in RQ]) for m in ('AP6', 'ESnp+1', 'TRAP', 'LCMV', 'AP_exactQ')]
        print(f'  Q={Q}: ' + ' / '.join(f'{v:.3f}' for v in vals))

json.dump({k: {m: {kk: (list(vv) if isinstance(vv, tuple) else float(vv)) for kk, vv in v.items()}
               if isinstance(v, dict) else list(v) for m, v in s.items()} for k, s in summary.items()},
          open('step12_partB_summary.json', 'w'), indent=1, default=float)
