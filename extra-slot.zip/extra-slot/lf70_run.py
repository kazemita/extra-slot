"""Replication with the user's 70-channel EEG lead field (PREREGISTRATION_LF70.md).

usage: python3 lf70_run.py PART NPARTS NREP SNR1,SNR2 [SEED0]      (one JSON line per realisation)
       python3 lf70_run.py diag                                   (correct-count diagnostic only)
"""
import paths
import os, sys, json, time
import numpy as np
import scipy.io as sio
from scipy.signal import butter, sosfiltfilt

sys.path.insert(0, paths.CORE); _here = os.getcwd()
import modelorder as mo
import lsq_generic as lg
os.chdir(_here)
mo.Problem, mo._best_complement, mo._exchange_from = lg.Problem, lg._best_complement, lg._exchange_from

G0 = sio.loadmat(paths.LEADFIELD)['gain'] * 1e-9          # per nAm
POS = sio.loadmat(paths.VOXELS)['l']
m = G0.shape[0]
H = np.eye(m) - np.ones((m, m)) / m                                               # average reference
ev, V = np.linalg.eigh(H); Ur = V[:, ev > 0.5]
G = Ur.T @ H @ G0                                                                  # r x 15002
r = G.shape[0]

# 7 mm lattice subsample for the inversion grid
key = np.floor(POS / 0.007).astype(int)
grid = {}
for i, k in enumerate(map(tuple, key)):
    d = np.linalg.norm(POS[i] - (np.array(k) + 0.5) * 0.007)
    if k not in grid or d < grid[k][0]:
        grid[k] = (d, i)
GRID_IDX = np.array(sorted(i for _, i in grid.values()))
mo.L = G[:, GRID_IDX].T[:, :, None].copy()                                        # (n_grid, r, 1)
mo.GRID = POS[GRID_IDX]; mo.ALL = np.arange(len(GRID_IDX))
nrm = np.linalg.norm(G, axis=0)
VIS = np.setdiff1d(np.where(nrm >= np.percentile(nrm, 30))[0], GRID_IDX)           # visible, never on-grid

FS = 250.0; TW, TN = 2000, 3000
SOS = butter(4, [5, 35], btype='band', fs=FS, output='sos')
SOS_BG = butter(2, [1, 45], btype='band', fs=FS, output='sos')


def pick_sources(Q, rng, min_sep=0.030):
    while True:
        idx = []
        for _ in range(500):
            j = int(rng.choice(VIS))
            if all(np.linalg.norm(POS[j] - POS[i]) >= min_sep for i in idx):
                idx.append(j)
            if len(idx) == Q:
                return idx


def simulate(Q, rho, snr, rng, n_bg=2000):
    idx = pick_sources(Q, rng)
    w = lambda: (lambda z: z / z.std())(sosfiltfilt(SOS, rng.standard_normal(TW + 600))[300:-300])
    common = w()
    S = np.array([np.sqrt(rho) * common + np.sqrt(1 - rho) * w() for _ in range(Q)]) * rng.uniform(10, 25, Q)[:, None]
    sig = G[:, idx] @ S
    bg_idx = rng.choice(G.shape[1], n_bg, replace=False); Gb = G[:, bg_idx]

    def brain(T):
        z = sosfiltfilt(SOS_BG, np.cumsum(rng.standard_normal((n_bg, T + 600)), axis=1), axis=1)[:, 300:-300]
        return Gb @ (z / z.std(axis=1, keepdims=True))
    bw, bb = brain(TW), brain(TN)
    scale = np.sqrt(r / np.sum(bw ** 2) * TW)                                     # brain power = sensor-noise power
    back = scale * bw + rng.standard_normal((r, TW))
    base = scale * bb + rng.standard_normal((r, TN))
    sig *= np.sqrt(snr * np.sum(back ** 2) / np.sum(sig ** 2))
    base -= base.mean(1, keepdims=True)
    return idx, back + sig, base @ base.T / TN, TN


def ap_restarts(f, q, n, rng):
    S = f.ap(q); best = (f.prob.explained(S), S)
    for _ in range(n - 1):
        Sk = f.polish(list(rng.choice(len(GRID_IDX), q, replace=False))); e_ = f.prob.explained(Sk)
        if e_ > best[0]:
            best = (e_, Sk)
    return best[1]


if __name__ == '__main__':
    if sys.argv[1] == 'diag':
        print(f'channels {m}, rank {r}, grid nodes {len(GRID_IDX)}, simulation candidates {len(VIS)}')
        p15 = {0.5: [], 2.0: []}
        for i in range(36):
            snr = (0.5, 2.0)[i % 2]; Q = 2 + (i // 2) % 3; rho = (1.0, 0.8, 0.3)[(i // 6) % 3]
            rng = np.random.default_rng(592000 + i)
            idx, data, eps, Tn = simulate(Q, rho, snr, rng)
            f = mo.Fit(data, eps, Tn)
            p15[snr].append(mo.score(f.ap(Q), POS[idx], 0.015)['precision'])
        allp = p15[0.5] + p15[2.0]
        print('correct-count precision@15: SNR 0.5 %.2f, SNR 2 %.2f, pooled %.2f -> use SNR %s'
              % (np.mean(p15[0.5]), np.mean(p15[2.0]), np.mean(allp), '{0.5, 2}' if np.mean(allp) >= 0.70 else '{2, 8}'))
        sys.exit()
    part, nparts, nrep = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    snrs = tuple(float(x) for x in sys.argv[4].split(','))
    seed0 = int(sys.argv[5]) if len(sys.argv) > 5 else 900000
    cells = [(Q, rho, snr) for Q in (2, 3, 4) for rho in (1.0, 0.8, 0.3) for snr in snrs]
    jobs = [(c, k) for c in cells for k in range(nrep)][part::nparts]
    for (Q, rho, snr), rep in jobs:
        seed = seed0 + 1000 * cells.index((Q, rho, snr)) + rep
        rng = np.random.default_rng(seed)
        idx, data, eps, Tn = simulate(Q, rho, snr, rng)
        pos = POS[idx]
        f = mo.Fit(data, eps, Tn); r2 = np.random.default_rng(seed + 9); q = Q - 1
        out = dict(Q=Q, rho=rho, snr=snr, rep=rep, seed=seed, k=f.prob.k, res={})

        def rec(name, S, t0):
            S = sorted(int(s) for s in S)
            s10, s15 = mo.score(S, pos, 0.010), mo.score(S, pos, 0.015)
            Dm = np.linalg.norm(mo.GRID[S][:, None] - pos[None], axis=2).min(1) * 1000
            out['res'][name] = dict(found=S, prec10=s10['precision'], rec10=s10['recall'], prec15=s15['precision'],
                                    rec15=s15['recall'], dist=float(Dm.mean()), expl=f.prob.explained(S),
                                    sec=time.time() - t0)
        t = time.time(); rec('AP', f.ap(q), t)
        t = time.time(); rec('AP6', ap_restarts(f, q, 6, r2), t)
        for extra in (1, 2):
            t = time.time(); rec(f'ESnp+{extra}', f.es_fixed(q, q + extra)[2], t)
        t = time.time(); rec('AP_exactQ', f.ap(Q), t)
        print(json.dumps(out), flush=True)
