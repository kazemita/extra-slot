"""Build the hybrid-test inputs from the MNE testing data and cache them in hybrid_inputs.npz.

* real MEG background: sample_audvis_trunc_raw.fif, good MEG channels, SSP applied, 1-40 Hz
* simulation forward: oct-6 cortical BEM forward, fixed normal orientation
* inversion forward: 7 mm volume BEM forward, reduced to 2 orientations per node
Everything is expressed in the r-dimensional range of the SSP projector.
"""
import paths
import numpy as np
import mne

TD = paths.TD + 'MEG/sample/'
raw = mne.io.read_raw_fif(TD + 'sample_audvis_trunc_raw.fif', preload=True, verbose=False)
raw.pick('meg', exclude='bads')
ch = raw.ch_names
P, nproj, _ = mne._fiff.proj.make_projector(raw.info['projs'], ch, bads=[])
raw.apply_proj(verbose=False)
raw.filter(1.0, 40.0, verbose=False)
X = raw.get_data()                                     # m x T, SI units
ev, V = np.linalg.eigh((P + P.T) / 2)
Ur = V[:, ev > 0.5]                                    # orthonormal basis of the projector range
r = Ur.shape[1]

def load_fwd(f, fixed):
    fwd = mne.read_forward_solution(TD + f, verbose=False)
    fwd = mne.pick_channels_forward(fwd, include=ch, ordered=True, verbose=False)
    assert fwd['sol']['row_names'] == ch
    if fixed:
        fwd = mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, use_cps=True, verbose=False)
    return fwd

f6 = load_fwd('sample_audvis_trunc-meg-eeg-oct-6-fwd.fif', fixed=True)
f7 = load_fwd('sample_audvis_trunc-meg-vol-7-fwd.fif', fixed=False)
G6 = Ur.T @ (P @ f6['sol']['data']) * 1e-9            # r x n6, per nAm, normal orientation
pos6 = f6['source_rr']
G7 = Ur.T @ (P @ f7['sol']['data']) * 1e-9            # r x 3*n7, per nAm (x,y,z per node)
pos7 = f7['source_rr']
n7 = len(pos7)
Xr = Ur.T @ X

# Two-orientation reduction of the volume lead fields, after whitening with the covariance of the
# whole recording (fixed across realisations; only used to choose the two kept orientations).
C_all = Xr @ Xr.T / Xr.shape[1]
e, Vc = np.linalg.eigh(C_all)
Wall = Vc @ np.diag(e ** -0.5) @ Vc.T
L7 = np.empty((n7, r, 2)); basis = np.empty((n7, 2, 3))
for j in range(n7):
    Gj = G7[:, 3 * j:3 * j + 3]
    _, _, Vt = np.linalg.svd(Wall @ Gj, full_matrices=False)
    L7[j] = Gj @ Vt[:2].T
    basis[j] = Vt[:2]

np.savez('hybrid_inputs.npz', X=Xr, sfreq=raw.info['sfreq'], G6=G6, pos6=pos6, L7=L7, pos7=pos7, basis=basis,
         ch=np.array(ch), rank=r)
print(f'channels {len(ch)}, SSP rank {r}, samples {Xr.shape[1]} ({Xr.shape[1] / raw.info["sfreq"]:.1f} s), '
      f'sim sources {G6.shape[1]}, grid nodes {n7}')
nrm = np.linalg.norm(Wall @ G6, axis=0)
print('whitened topography norm percentiles (10/30/50/90):', np.percentile(nrm, [10, 30, 50, 90]).round(2))
