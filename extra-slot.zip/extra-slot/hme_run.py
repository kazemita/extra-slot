"""Part A setting (PREREGISTRATION_STEP12.md): eeg_run.py data and fitting model, but sources simulated with
one of six perturbed 'true' head models (skull 0.0125 S/m + co-registration error), model = rep mod 6."""
import numpy as np
import eeg_run as E                                   # nominal fitting model, real EEG background, helpers

H = np.load('hme_inputs.npz')
G6S = H['G6s']                                       # (6, r, 7928), NaN columns = vertex outside perturbed skull
G6_NOMINAL = E.G6.copy()
VIS_NOMINAL = E.VIS.copy()
pos6 = E.pos6; mo = E.mo; ap_restarts = E.ap_restarts


def simulate_k(k, Q, rho, snr, rng):
    """identical to eeg_run.simulate, but the signal comes from perturbed model k"""
    valid = ~np.isnan(G6S[k][0])
    E.G6 = np.where(np.isnan(G6S[k]), 0.0, G6S[k])
    E.VIS = VIS_NOMINAL[valid[VIS_NOMINAL]]
    try:
        return E.simulate(Q, rho, snr, rng)
    finally:
        E.G6, E.VIS = G6_NOMINAL, VIS_NOMINAL
