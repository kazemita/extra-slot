# Step 3 — why an under-counted fit lands between sources, and why EEG is hit harder

## 1. Omitted-source bias in one line of algebra
Whitened, noise-free data from two sources with unit-norm topographies a1, a2 (overlap c = a1ᵀa2), equal
power s and temporal correlation r have covariance

  C = s [a1 a2] [[1, r], [r, 1]] [a1 a2]ᵀ.

A one-source least-squares fit chooses the topography b (‖b‖ = 1) that maximises the explained power bᵀCb.

* A true source explains P(a1) = s(1 + c² + 2rc).
* The best possible single topography is the top eigenvector of C. For c + r > 0 it is v ∝ a1 + a2 (the
  "sum" pattern) and explains λ1 = s(1 + c)(1 + r).
* The gap is λ1 − P(a1) = s(1 − c)(c + r) ≥ 0, with equality only for c = 1 (identical topographies) or
  c = −r. (Checked numerically on 20,000 random cases: 0 failures.)

So with one slot too few, the least-squares objective itself prefers a pattern that is not produced by any
true source. Whether the fit actually lands between the sources depends on one thing: is there a grid
location whose topography resembles v closely enough? For r = 1 (rank-one C) the condition is exact: a
compromise wins when some node captures more of v than either true source does, i.e.
(bᵀv)² > (1 + c² + 2rc) / ((1 + c)(1 + r)) — that is, more than 1/2 for well-separated sources (c ≈ 0).

Two consequences follow directly:
1. **More restarts cannot fix it.** The compromise is the best solution of the wrong objective, not a local
   optimum. AP with six restarts explains at least as much power as the extra-slot answer in 806 of 810
   realisations of the three EEG settings (and 359 of 360 noise-free runs), while being further from the
   true sources; restarts (AP6 vs AP) add only 0.00–0.03 in precision.
2. **Fitting one slot more removes the incentive.** With R ≥ Q slots the true locations already explain
   (almost) all the signal, so a compromise location brings no gain. Pruning the R-slot answer back to q
   slots by explained power then chooses *among true locations*: even a "wrong" choice of which source to
   drop is still a correct location. Re-fitting the pruned subset (CoSaMP / Subspace-Pursuit style) brings
   back the q-slot objective and with it the compromise — and indeed the re-fitted variant ESpol+1 loses
   almost all of the gain (EEG: 0.686 vs 0.802 for ES+1; AP 0.675).

## 2. Why EEG and not MEG (same subject, same cortical sources, same 4,157-node grid)
EEG potentials are smeared by the skull, so (i) topographies of separated sources overlap more and (ii) the
grid contains locations — typically between the two sources and a little deeper — whose broad field looks
like the sum of the two. MEG fields are focal; a single location rarely mimics the sum of two separated
patterns.

Exhaustive noise-free test (400 source pairs ≥ 30 mm apart; best single node over the whole grid):

| | MEG | EEG |
|---|---|---|
| overlap \|c\|, 30–50 mm apart (median) | 0.19 | 0.29 |
| overlap \|c\|, 50–70 mm apart | 0.07 | 0.12 |
| how well the best node mimics the sum pattern, r = 1 (median) | 0.74 | 0.81 |
| best node > 10 mm from both sources, r = 1.0 / 0.8 / 0.3 | 0.09 / 0.06 / 0.02 | 0.35 / 0.26 / 0.17 |
| best node > 15 mm from both sources, r = 1.0 | 0.03 | 0.18 |
| same, by separation 30–50 / 50–70 / 70–100 / >100 mm (r = 1) | 0.09 / 0.05 / 0.01 / 0.01 | 0.29 / 0.26 / 0.17 / 0.06 |

The compromise is stronger for correlated sources (r) and for balanced amplitudes, exactly as the formula
predicts. Compromise nodes sit slightly deeper than the true sources (median 4–5 mm closer to the head
centre in EEG).

Full pipeline with essentially no noise (SNR = 1000, real background, Q − 1 slots, 180 realisations per
modality): precision at 10 mm, AP6 vs ES+1 — **MEG 0.94 vs 0.96; EEG 0.72 vs 0.94**. The EEG error is
therefore a model-order bias, present without noise, and the extra slot removes most of it. This matches
the pre-registered results: MEG NO-GO (+0.012), EEG GO (+0.107).

## 3. Where the method stops helping
* **Q = 4 (q = 3).** The extra slot only helps if the R = Q fit is itself right. With 58 channels at these
  SNRs, AP with the correct count of 4 has precision ≈ 0.52–0.63 (vs ≈ 0.88 at Q = 2), so the extra-slot
  answer inherits those errors; at Q = 4 the gain is −0.01 to +0.02 across the three EEG settings.
* **Weakly correlated, well-separated sources (r = 0.3).** The gap s(1 − c)(c + r) is small and few
  compromises occur; gains shrink accordingly.
* **MEG.** Few compromises to remove (see table).
