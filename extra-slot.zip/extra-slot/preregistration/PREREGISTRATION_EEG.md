# Pre-registration: EEG version of the decisive hybrid test (written before any EEG data were analysed)

Date: 15 October 2026. Follows the MEG test in `PREREGISTRATION.md`, which ended NO-GO (+0.012
[−0.004, +0.030]). The hypothesis is that EEG, with fewer channels and broader lead fields, still shows the
"compromise position" failure of under-counted fits, so that extra slots help. Agreed plan: if this test
also fails (or is invalid), the extra-slot results are folded into a benchmark paper (paper 3).

## Question
With **real EEG background activity**, when fewer sources are fitted than are active (assumed count Q−1),
does keeping a subset of a larger fit (ESnp+1) report true sources more often than alternating
projection with the same compute (AP6)?

## Data
* Background: the same MNE "sample" recording (`sample_audvis_trunc_raw.fif`, 20 s, 300 Hz), EEG channels
  only (60 minus the channel marked bad), with the recording's average-reference projector applied to data
  and lead fields, 1–40 Hz band-pass. Real spontaneous and evoked activity plus ocular and other artefacts
  are left in, as they would be in practice before cleaning.
* Each realisation draws a random 2,400-sample (8 s) data window; the remaining samples estimate the noise
  covariance.
* Simulated sources: random vertices of the oct-6 cortical source space (7,928 vertices), fixed
  orientation normal to the cortex, at least 30 mm apart, restricted to vertices whose whitened EEG
  topography norm is at or above the 30th percentile. Waveforms: band-limited 5–35 Hz noise with pairwise
  correlation rho, rms amplitudes uniform in 10–25 nAm, scaled together to the target SNR.
* SNR = total simulated signal power / total background power in the data window, after whitening with the
  fixed covariance of the whole recording.
* Forward models: EEG forward solutions computed with MNE-Python from the testing data's three-layer BEM
  solution (`sample-1280-1280-1280-bem-sol.fif`) and the recording's head transform, for both the oct-6
  cortical source space (simulation) and the 7 mm volume grid of the MEG test (inversion, 4,157 nodes). The
  same conductor model is used for simulation and inversion (no conductivity error).

## Inversion
* All **three** dipole orientations are kept at each grid node (EEG, unlike MEG, sees radial sources).
  The search code is the generic-orientation version (`lsq_generic.py`), shown to reproduce the original
  code exactly for two orientations (`test_lsq_generic.py`).
* Rank-reduced to the range of the average-reference projector, whitened with the realisation's noise
  covariance.

## Design
Q ∈ {2, 3, 4} × rho ∈ {1.0, 0.8, 0.3} × SNR ∈ {0.5, 2} × 15 realisations = 270 realisations.
Seeds 700000 + 1000·cell + rep (not used before).

## Methods (assumed count Q−1)
AP; AP6 (best of AP and 5 random restarts by explained signal power); ESnp+1 (primary); ESnp+2
(secondary); AP(Q) with the correct count as a validity check. Identical to the MEG test.

## Primary endpoint and decision rule (identical to the MEG test)
Precision at 10 mm; paired difference ESnp+1 − AP6 pooled over all 270 realisations; 95% bootstrap CI
(4,000 resamples, seed 0).
* **GO**: mean difference ≥ 0.10 and CI lower bound > 0.
* **MODEST**: CI lower bound > 0 but mean < 0.10.
* **NO-GO**: CI lower bound ≤ 0.

Validity: if AP with the correct count has pooled precision at 15 mm below 0.60, the setup is declared
invalid, the decision is withheld, and (as agreed) we proceed to paper 3.

## Secondary (reported, not decisive)
Precision at 15 mm; mean distance of reported sources to the nearest true source; ESnp+2; breakdown by
rho, Q and SNR.

## Known limitations
One 20-s recording reused across realisations; one subject; no conductivity or co-registration error,
which in real EEG is a major error source and would affect all methods.
