# Pre-registration: head-model error (Part A) and baselines + runtime (Part B) for the short EEG paper

Date: 15 October 2026. Written before any of the runs below.

## Part A — does the extra-slot advantage survive head-model error? (decisive)
* Background: the real 60-channel EEG recording used in the EEG test (`eeg_inputs.npz`): average
  reference, 1–40 Hz, 8-s windows, noise covariance from the rest of the recording.
* "True" head models used to simulate the data: six perturbed models, each combining
  (i) skull conductivity 0.0125 S/m (skull-to-brain ratio 1:24) instead of the 0.006 S/m (1:50) used for
  fitting, and (ii) a co-registration error: rotation of 2° about a random axis through the head origin and
  translation of 4 mm in a random direction, applied to the head-to-MRI transform (six independent draws,
  seed 4242). Realisation `rep` uses model `rep mod 6`.
* Fitting always uses the nominal model (0.006 S/m, unperturbed transform), i.e. the existing EEG grid.
* Errors are measured in the anatomical (MRI) frame: true cortical vertex vs reported grid node, both
  mapped with the nominal transform, so co-registration error produces real localisation error.
* Sources, waveforms, visibility rule, SNR definition, methods: as in the EEG test.
* SNR rule (fixed now): a correct-count diagnostic on seeds 593000+ (AP with the correct count only, SNR 0.5
  and 2) chooses SNR ∈ {0.5, 2} if its pooled precision at 15 mm is ≥ 0.70, otherwise SNR ∈ {2, 8}.
* Design: Q ∈ {2,3,4} × rho ∈ {1.0, 0.8, 0.3} × 2 SNRs × 15 = 270 realisations; seeds
  1000000 + 1000·cell + rep.
* Endpoint: precision at 10 mm, paired difference ESnp+1 − AP6, pooled, 95% bootstrap CI (4,000
  resamples, seed 0). **SURVIVES** if the CI lower bound > 0 (also classified GO/MODEST as before);
  **DOES NOT SURVIVE** otherwise. Validity: AP with the correct count, pooled precision at 15 mm ≥ 0.60,
  otherwise the decision is withheld.

## Part B — baselines and runtime (descriptive, no decision rule)
Settings and realisations: (i) EEG test (seeds 700000+, SNR {0.5, 2}); (ii) user's 70-channel lead field
(seeds 900000+, SNR {2, 8}); (iii) Part A (its seeds and SNRs). Assumed count Q−1 throughout.

Methods (all on the same whitened data and grid):
* AP; AP6; ESnp+1; ESnp+2 — as before.
* **ESpol+1**: extra slot, then re-fit the kept subset with AP iterations (CoSaMP / Subspace Pursuit style).
* **TRAP-MUSIC** (Mäkelä et al., 2018): signal subspace of dimension Q−1 from the whitened data covariance,
  truncated recursive projection, vector lead fields with optimal orientation.
* **LCMV peaks**: unit-noise-gain vector beamformer (neural activity index with optimal orientation) on the
  whitened data covariance regularised by 5% of its mean eigenvalue; the Q−1 highest nodes at least 20 mm
  apart (greedy).

Reported: precision at 10 and 15 mm, mean distance to the nearest true source, paired differences
ESnp+1 − each method with 95% bootstrap CIs, and wall-clock time per method (single BLAS thread, same
machine), with the shared preparation time (whitening, signal subspace) reported separately.
