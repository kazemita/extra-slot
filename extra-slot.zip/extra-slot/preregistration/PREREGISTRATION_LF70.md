# Pre-registration: replication with an independent EEG head model (user's 70-channel lead field)

Date: 15 October 2026. Written before the lead field was used for any localisation.

## Context
EEG test (sample subject, 60 channels, real background): GO, +0.107 [+0.064, +0.149]. Independent
recording (EEGLAB, 30 channels): inconclusive (validity check failed). This test asks whether the effect
holds with a **different anatomy, electrode cap and source model**. No matching EEG recording exists, so
the background is simulated brain activity: this tests generality across head models, not the real
background.

## Head model and source model
* Lead field supplied by the user (`Leadfield2.mat`, `gain`, 70 channels × 15,002 cortical vertices, fixed
  orientation; `voxelLocation2.mat`, vertex positions in metres), as used in Sotudeh et al. (2023).
  Average reference applied to all lead fields (rank 69).
* Inversion grid: vertices subsampled on a 7 mm cubic lattice (in each occupied 7 mm cube, the vertex
  closest to the cube centre), one fixed orientation per node (`lsq_generic.py` with one orientation).
* Simulated sources: vertices **not** in the inversion grid (always off-grid), at least 30 mm apart, with
  topography norm at or above the 30th percentile of all vertices.

## Signals and background
* 250 Hz sampling; data window 8 s (2,000 samples); separate baseline 12 s (3,000 samples) for the noise
  covariance.
* Sources: band-limited 5–35 Hz noise with pairwise correlation rho; rms amplitudes uniform 10–25 nAm.
* Background (drawn fresh for each realisation, same generators in data window and baseline): 2,000 random
  cortical vertices with independent 1/f-like activity (1–45 Hz), scaled so that its total power equals
  that of white sensor noise; brain + sensor noise together form the background.
* SNR = total signal power / total background power in the data window (average-referenced sensor space;
  all channels share units).

## SNR levels (rule fixed now)
A correct-count pipeline diagnostic is run first on seeds 59xxxx (outside the test range), computing only
AP with the correct count at SNR 0.5 and 2. If its pooled precision at 15 mm is at least 0.70, the test uses
SNR ∈ {0.5, 2}; otherwise SNR ∈ {2, 8}. No extra-slot results are computed in the diagnostic.

## Design
Q ∈ {2, 3, 4} × rho ∈ {1.0, 0.8, 0.3} × two SNR levels × 15 realisations = 270 realisations.
Seeds 900000 + 1000·cell + rep (not used before).

## Methods, endpoint and decision rule (identical to the earlier tests)
AP, AP6, ESnp+1 (primary), ESnp+2, AP(Q) for validity, all with assumed count Q−1. Precision at 10 mm,
paired difference ESnp+1 − AP6, pooled, 95% bootstrap CI (4,000 resamples, seed 0).
* **REPLICATED (GO)**: mean ≥ 0.10 and CI lower bound > 0.
* **PARTLY (MODEST)**: CI lower bound > 0 but mean < 0.10.
* **NOT REPLICATED (NO-GO)**: CI lower bound ≤ 0.
Validity: AP with the correct count, pooled precision at 15 mm ≥ 0.60, otherwise the decision is withheld.

## Known limitations
Simulated background; the same lead field generates and fits the data (no conductivity error), apart
from off-grid positions and orientations.
