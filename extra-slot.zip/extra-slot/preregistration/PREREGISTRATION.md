# Pre-registration: decisive hybrid test of extra slots (written before any hybrid data were analysed)

Date: 15 October 2026. This file is fixed before running `hybrid_run.py`; later analyses not listed
here are labelled exploratory.

## Question
With **real MEG background activity**, when fewer sources are fitted than are active (assumed count
Q−1), does keeping a subset of a larger fit ("extra slots", ESnp+1) report true sources more often than
alternating projection (AP) given the same compute (best of 6 restarts, AP6)?

## Data
* Background: MNE "sample" recording from the MNE testing data (`sample_audvis_trunc_raw.fif`, 20 s,
  300 Hz, Elekta Vectorview), good MEG channels only, SSP projectors applied, 1–40 Hz band-pass. It
  contains genuine spontaneous and evoked brain activity plus environmental and sensor noise.
* Each realisation draws a random 2,400-sample (8 s) data window; the remaining samples of the recording
  (not overlapping the window) estimate the noise covariance.
* Simulated sources: random vertices of the sample subject's oct-6 cortical source space (7,928
  vertices; BEM forward from the testing data), fixed orientation normal to the cortex, at least 30 mm
  apart, restricted to vertices whose MEG topography norm is at or above the 30th percentile (MEG-visible
  sources). Waveforms: band-limited 5–35 Hz noise with pairwise correlation rho, rms amplitudes uniform
  in 10–25 nAm, then scaled together to the target SNR.
* SNR = total simulated signal power / total background power in the data window (sensor space, after
  SSP and filtering).

## Inversion
* Volume grid from the same subject's BEM forward (7 mm, 4,157 nodes): sources are off-grid. Each node's
  three-orientation lead field is reduced to its two strongest orientations (SVD after whitening with the
  covariance of the whole recording, fixed across realisations), as in the earlier simulations.
* Rank-reduced to the range of the SSP projector, whitened with the realisation's noise covariance.
* Same search code as the earlier pilot (`modelorder.py`, `lsq_methods.py`).

## Design
Q ∈ {2, 3, 4} × rho ∈ {1.0, 0.8, 0.3} × SNR ∈ {0.5, 2} × 15 realisations = 270 realisations.
Seeds 600000 + 1000·cell + rep (not used before).

## Methods (assumed count Q−1)
* AP: alternating projection, sequential initialisation, whole grid.
* AP6: best (by explained signal power) of AP and 5 random-start restarts.
* ESnp+1 (primary): AP with Q slots, keep the Q−1 subset explaining most power, no re-polish.
* ESnp+2 (secondary): the same with Q+1 slots.
* AP(Q) with the correct count: sanity check only.

## Primary endpoint and decision rule
Precision at 10 mm (fraction of reported sources within 10 mm of a distinct true source, one-to-one
matching). Paired difference ESnp+1 − AP6, pooled over all 270 realisations; 95% bootstrap CI (4,000
resamples, seed 0).
* **GO**: mean difference ≥ 0.10 and CI lower bound > 0.
* **MODEST**: CI lower bound > 0 but mean < 0.10.
* **NO-GO**: CI lower bound ≤ 0.

Validity check: if AP with the correct count Q has pooled precision at 15 mm below 0.60, the setup is
declared invalid (not a test of the method) and the decision is withheld.

## Secondary (reported, not decisive)
Precision at 15 mm; mean distance of reported sources to the nearest true source; ESnp+2; breakdown by
rho, Q and SNR.

## Known limitations
One 20-s recording is reused across realisations (windows differ); one subject; no head-model error.

## Clarification added before the first run (no hybrid results seen)
Magnetometer and gradiometer signals have different units, so "total power" is computed after whitening
with the fixed covariance of the whole recording (the same matrix used for the orientation reduction).
SNR and the "MEG-visible" threshold (30th percentile of whitened topography norms) both use this whitened
space. The decision rule is unchanged.
