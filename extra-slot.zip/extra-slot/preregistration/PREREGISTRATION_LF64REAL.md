# Pre-registration: user's lead field with REAL background EEG (64-channel BioSemi recording)

Date: 15 October 2026. Written before the recording was used for any simulation or localisation (it has
only been used to check the channel order, see `chancheck/`).

## Context
The 70-channel lead-field test used simulated brain activity (MODEST, +0.069 [+0.032, +0.107]). The user
has now supplied the resting-state recording that goes with this lead field
(`sub-015_ses-t1_task-resteyesc_eeg.edf`: 64 channels, BioSemi-64 layout, 1024 Hz, 240 s, eyes closed,
average-referenced). This test repeats the lead-field test with the real recording as background.

## Channel mapping (fixed now)
The lead field has 70 rows without labels. Rows 1–64 in stored order do not match the recording
(`chancheck/validate_tests.txt`). The test uses the order reconstructed from the lead field's geometry alone
(`chancheck/refined_order.npy`; agreement with the recording's channel correlations 0.81, vs 0.84 for a known
correct mapping on MNE sample data and 0.10 for rows 1–64). The six unassigned rows are dropped. A few
neighbouring channels may still be swapped; this is a stated limitation.

## Head model, grid, sources (as in the 70-channel test)
* Lead field `gain`, the 64 mapped rows, average reference (rank 63, analysis in the 63-dimensional
  reduced space).
* Inversion grid: the same 7 mm lattice subsample (3,554 nodes, fixed orientation).
* Simulated sources: off-grid vertices, ≥ 30 mm apart, visible (whitened topography norm ≥ 30th
  percentile, whitening with the whole-recording covariance, as in the sample-subject EEG test).
* Sources: band-limited 5–35 Hz noise, pairwise correlation rho, rms amplitudes uniform 10–25.

## Background
* Recording filtered 1–45 Hz (zero-phase), resampled to 256 Hz, first and last 2 s discarded.
* Data window: 8 s (2,048 samples) at a random position per realisation; noise covariance from the rest of
  the recording (as in the sample-subject EEG test). No added white noise.
* SNR = total signal power / total background power in the data window (whitened by the whole-recording
  covariance, as in the sample-subject EEG test).

## SNR levels (rule fixed now)
Correct-count diagnostic on seeds 594000–594035 (AP with the correct count only, SNR 0.5 and 2). Pooled
precision at 15 mm ≥ 0.70 → SNR ∈ {0.5, 2}; otherwise SNR ∈ {2, 8}.

## Design, endpoint and decision rule (identical to the earlier tests)
Q ∈ {2, 3, 4} × rho ∈ {1.0, 0.8, 0.3} × two SNRs × 15 = 270 realisations; seeds 1100000 + 1000·cell + rep.
Methods with assumed count Q−1: AP, AP6, ESnp+1 (primary), ESnp+2, ESpol+1, TRAP-MUSIC, LCMV peaks;
AP(Q) for validity. Primary endpoint: precision at 10 mm, paired difference ESnp+1 − AP6, pooled, 95%
bootstrap CI (4,000 resamples, seed 0).
* **GO**: mean ≥ 0.10 and CI lower bound > 0.
* **MODEST**: CI lower bound > 0 but mean < 0.10.
* **NO-GO**: CI lower bound ≤ 0.
Validity: AP with the correct count, pooled precision at 15 mm ≥ 0.60, otherwise the decision is withheld.

## Descriptive arms (no decision rule), same seeds and SNRs
* **A: Main.m mapping** — lead-field rows 1–64 in stored order with the recording's channels in EDF order
  (as in the user's MATLAB code). Shows how much a channel-scrambled background changes the results.
* **B: mapping uncertainty** — the unrefined reconstructed order (`chancheck/recovered_order.npy`, 18 channels
  differ from the refined order). Shows sensitivity to residual channel swaps.

## Known limitations
One subject's recording; channel order reconstructed, not documented; the same lead field generates and
fits the data (no conductivity or co-registration error — that was tested in Part A of
PREREGISTRATION_STEP12.md).
