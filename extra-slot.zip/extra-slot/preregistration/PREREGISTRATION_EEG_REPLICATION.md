# Pre-registration: independent EEG replication (written before any replication data were analysed)

Date: 15 October 2026. The EEG test in `PREREGISTRATION_EEG.md` gave GO: precision at 10 mm,
ESnp+1 − AP6 = +0.107 [95% CI +0.064, +0.149]. This test asks whether that holds with an independent EEG
recording (different person, laboratory, amplifier, electrode layout and sampling rate).

## Data
* Background: the EEGLAB tutorial recording (`sample_data/eeglab_data.set` from the sccn/eeglab GitHub
  repository): 32 channels, 128 Hz, 238 s. The two EOG channels are excluded, leaving 30 scalp channels;
  average reference (as a projector applied to data and lead fields); 1–40 Hz band-pass; artefacts left in.
* Electrode positions: standard 10-05 positions by channel name (MNE `standard_1005`). The person's own
  anatomy is not available, so the MNE "sample" subject serves as a template head: its three-layer BEM,
  with MNE projecting the electrodes onto the scalp.
* Data windows of 8 s (1,024 samples); the noise covariance is estimated from a random 12-s segment
  (1,536 samples) that does not overlap the window, matching the durations of the earlier tests.
* Simulated sources, waveforms, visibility rule (30th percentile of whitened topography norms), SNR
  definition (after whitening with the fixed covariance of the whole recording) and amplitudes: as in the
  EEG test.

## Inversion
Same 7 mm volume grid (4,157 nodes), three orientations per node, `lsq_generic.py`, same search code.

## Design
Q ∈ {2, 3, 4} × rho ∈ {1.0, 0.8, 0.3} × SNR ∈ {0.5, 2} × 15 realisations = 270 realisations.
Seeds 800000 + 1000·cell + rep (not used before).

## Methods, endpoint and decision rule
Identical to the EEG test: AP, AP6, ESnp+1 (primary), ESnp+2, AP(Q) for validity. Precision at 10 mm,
paired difference ESnp+1 − AP6, pooled over 270 realisations, 95% bootstrap CI (4,000 resamples, seed 0).
* **REPLICATED (GO)**: mean ≥ 0.10 and CI lower bound > 0.
* **PARTLY REPLICATED (MODEST)**: CI lower bound > 0 but mean < 0.10.
* **NOT REPLICATED (NO-GO)**: CI lower bound ≤ 0.
Validity: AP with the correct count must reach pooled precision at 15 mm ≥ 0.60, otherwise the decision is
withheld.

## Known limitations
Template head (not the person's anatomy) and standard electrode positions: this adds realistic
head-model error to the background but is the same for all methods. No other EEG recording with enough
channels and duration was reachable from this environment.

## Clarification added before the first run (no replication results seen)
The MNE development version used here no longer has a montage called `standard_1005`; its 10-05 sets are
now named by template head. We use `fsaverage_1005` (standard 10-05 positions on the fsaverage template
head), matching channels by name case-insensitively. Nothing else changes.

## Amendment before any test-seed run (only correct-count diagnostics on separate seeds 591000+ seen)
A pipeline diagnostic (`eeg2_diag.py`, seeds outside the test range, AP with the correct count only; no
extra-slot results computed) showed the pipeline is sound (white background, SNR 20: precision at 15 mm
0.85, median error 4.7 mm) but that this 30-channel recording is hard at the registered SNRs (real
background: 0.40 at SNR 0.5, 0.55 at SNR 2). The registered design may therefore fail its validity check.
* **Arm A (as registered, primary):** SNR ∈ {0.5, 2}, seeds 800000+. Run unchanged.
* **Arm B (added now):** identical except SNR ∈ {2, 8}, seeds 850000 + 1000·cell + rep, 270 realisations.
* Interpretation fixed now: if Arm A passes its validity check, its decision is the replication result and
  Arm B is reported as secondary. If Arm A is invalid, Arm B's decision (with its own validity check)
  is the replication result. Both are reported in full either way.
