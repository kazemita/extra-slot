"""Does the user's 70-row lead field match the 64-channel BioSemi recording, and in which order?
Two independent checks of the hypothesis 'lead-field rows 1-64 = EDF channels in EDF order':
 (1) geometry: electrode positions estimated from the lead field (the cortical sources each row is most
     sensitive to) vs the standard BioSemi-64 positions, after a best similarity transform (Procrustes);
 (2) correlation structure: channel-correlation matrix of the resting EEG vs the one implied by the lead field
     (random cortical sources), off-diagonal Spearman correlation.
Each is compared with 2,000 random channel orders (null) and with the alternative 'rows 7-70'."""
import paths
import sys
import numpy as np
import scipy.io as sio
from scipy.stats import spearmanr
from scipy.signal import butter, sosfiltfilt
import mne

EDF = paths.EDF
G = sio.loadmat(paths.LEADFIELD)['gain']          # (70, 15002)
loc = sio.loadmat(paths.VOXELS)['l']       # (15002, 3)
raw = mne.io.read_raw_edf(EDF, preload=True, verbose=False)
ch = raw.ch_names
X = raw.get_data()
print('lead field', G.shape, '| row norms min/median/max', np.round(np.percentile(np.linalg.norm(G, axis=1), [0, 50, 100]), 3))
print('column sums ~ 0 (average reference)?', np.abs(G.sum(0)).max() / np.abs(G).max())
print('source coordinates range per axis', np.round(loc.min(0), 3), np.round(loc.max(0), 3))
print('EEG', X.shape, 'sfreq', raw.info['sfreq'], '| raw channel SD in file units (values are microvolts although the '
      'header says V; includes DC drift) min/median/max', np.round(np.percentile(X.std(1), [0, 50, 100]), 1))

# ---------- (1) geometry --------------------------------------------------------------------------------
mont = mne.channels.make_standard_montage('biosemi64')
mp = mont.get_positions()['ch_pos']
T = np.array([mp[c] for c in ch])                                       # template, EDF order (m)
Ga = G - G.mean(0)                                                      # average reference
cen = loc.mean(0)
sup = np.linalg.norm(loc - cen, axis=1) >= np.percentile(np.linalg.norm(loc - cen, axis=1), 70)   # outer 30%
est = []
for i in range(G.shape[0]):
    w = np.abs(Ga[i, sup]); top = np.argsort(-w)[:30]
    est.append(np.average(loc[sup][top], axis=0, weights=w[top]))
est = np.array(est)


def procrustes_rms(A, B):
    """rms distance after the best similarity transform mapping A onto B (both n x 3); in units of B"""
    a, b = A - A.mean(0), B - B.mean(0)
    U, s, Vt = np.linalg.svd(a.T @ b)
    D = np.eye(3); D[2, 2] = np.sign(np.linalg.det(U @ Vt))
    R = U @ D @ Vt; sc = np.trace(np.diag(s) @ D) / np.sum(a ** 2)
    return np.sqrt(np.mean(np.sum((sc * a @ R - b) ** 2, axis=1)))


rng = np.random.default_rng(0)
geo = {'rows 1-64': procrustes_rms(est[:64], T), 'rows 7-70': procrustes_rms(est[6:], T)}
null = np.array([procrustes_rms(est[rng.permutation(70)[:64]], T) for _ in range(2000)])
print('\n(1) geometry, rms electrode mismatch after similarity fit (mm, template scale):')
for k, v in geo.items():
    print(f'    {k}: {v * 1000:.1f}  (random orders: median {np.median(null) * 1000:.1f}, '
          f'min {null.min() * 1000:.1f}; fraction <= this: {np.mean(null <= v):.4f})')

# ---------- (2) correlation structure -------------------------------------------------------------------
sos = butter(4, [1, 40], btype='band', fs=raw.info['sfreq'], output='sos')
Xf = sosfiltfilt(sos, X - X.mean(0), axis=1)[:, 2048:-2048]            # average reference, 1-40 Hz
Ce = np.corrcoef(Xf)
iu = np.triu_indices(64, 1)


def model_corr(rows):
    g = G[rows] - G[rows].mean(0)
    C = g @ g.T                                                          # white random sources
    d = np.sqrt(np.diag(C)); return C / np.outer(d, d)


cs = {'rows 1-64': spearmanr(model_corr(np.arange(64))[iu], Ce[iu])[0],
      'rows 7-70': spearmanr(model_corr(np.arange(6, 70))[iu], Ce[iu])[0]}
nullc = np.array([spearmanr(model_corr(rng.permutation(70)[:64])[iu], Ce[iu])[0] for _ in range(2000)])
print('\n(2) Spearman correlation, EEG channel correlations vs lead-field-implied correlations:')
for k, v in cs.items():
    print(f'    {k}: {v:.3f}  (random orders: median {np.median(nullc):.3f}, max {nullc.max():.3f}; '
          f'fraction >= this: {np.mean(nullc >= v):.4f})')

# ---------- (3) neighbour structure -----------------------------------------------------------------------
DT = np.linalg.norm(T[:, None] - T[None], axis=2)
Cr = np.corrcoef(Ga)                                                     # 70 x 70 lead-field row correlations


def frac(rows):
    C = Cr[np.ix_(rows, rows)].copy(); np.fill_diagonal(C, -np.inf)
    return np.mean(DT[np.arange(64), np.argmax(C, 1)] < 0.045)


nulln = [frac(rng.permutation(70)[:64]) for _ in range(2000)]
print('\n(3) is each row\'s most similar other row a BioSemi neighbour (< 45 mm)? (a correct order should give ~0.9)')
for k, rows in (('rows 1-64', np.arange(64)), ('rows 7-70', np.arange(6, 70))):
    print(f'    {k}: {frac(rows):.2f}  (random orders: median {np.median(nulln):.2f}, 99.9th pct {np.percentile(nulln, 99.9):.2f})')
print('\nconclusion: both shifted hypotheses score alike and far below a correct match, so the row order cannot be'
      ' established from the data; the electrode labels of the lead field are needed.')
