"""Step 3 - mechanism of the under-count error, MEG vs EEG (same subject, same cortical sources, same grid).

M1 (exhaustive, noise-free, Q = 2 sources fitted with q = 1 slot): for random source pairs, the single grid node
    that explains most of the noise-free signal covariance, its distance to the nearest true source, the
    topographic overlap c of the two sources, and how well the best node mimics the 'sum' topography (the top
    eigenvector of the signal covariance).
M2 (pipeline, essentially noise-free, SNR = 1000): AP, AP6 and ESnp+1 with Q-1 slots on the same simulator as the
    tests, for Q = 2 and 3.

usage: python3 mechanism.py meg|eeg   -> one JSON line per item (prefixed M1/M2) to stdout
"""
import sys, json
import numpy as np

mod = sys.argv[1]
S = __import__('hybrid_run' if mod == 'meg' else 'eeg_run')
mo = S.mo
G6, pos6, L7, pos7, W, VIS = S.G6, S.pos6, S.L7, S.pos7, S.WALL, S.VIS

# ---------- M1 ----------------------------------------------------------------------------------------------
Aw = W @ G6                                                   # whitened cortical topographies (m, 7928)
Lw = np.einsum('ab,pbo->pao', W, L7)                          # whitened grid lead fields (p, m, no)
U = np.linalg.svd(Lw, full_matrices=False)[0]                 # orthonormal basis per node (p, m, no)
rng = np.random.default_rng(31)
npairs = 400
for n in range(npairs):
    i, j = S.pick_sources(2, rng)
    amp = rng.uniform(10, 25, 2)
    a = Aw[:, [i, j]]
    an = a / np.linalg.norm(a, axis=0)
    c = float(abs(an[:, 0] @ an[:, 1]))
    sep = float(np.linalg.norm(pos6[i] - pos6[j]) * 1000)
    dn = np.linalg.norm(pos7[:, None] - pos6[[i, j]][None], axis=2).min(1) * 1000      # node -> nearest true (mm)
    for r in (1.0, 0.8, 0.3):
        Sig = np.diag(amp) @ np.array([[1, r], [r, 1]]) @ np.diag(amp)
        w_, V_ = np.linalg.eigh(Sig); Lc = V_ * np.sqrt(np.maximum(w_, 0))   # Sig = Lc Lc^T (rank 1 if r = 1)
        M = a @ Lc                                            # C = M M^T (noise-free whitened signal covariance)
        e = np.sum(np.einsum('pmo,mk->pok', U, M) ** 2, axis=(1, 2))   # explained power of each single node
        g = int(np.argmax(e))
        near = dn <= 10.0
        vtop = np.linalg.svd(M, full_matrices=False)[0][:, 0]
        mim = np.sum(np.einsum('pmo,m->po', U, vtop) ** 2, axis=1)
        lam = np.linalg.svd(M, compute_uv=False) ** 2
        out = dict(part='M1', mod=mod, pair=n, r=r, sep_mm=sep, c=c, c_signed=float(an[:, 0] @ an[:, 1]), amp_ratio=float(amp.min() / amp.max()),
                   best_dist_mm=float(dn[g]), best_depth_mm=float(np.linalg.norm(pos7[g]) * 1000),
                   true_depth_mm=float(np.linalg.norm(pos6[[i, j]], axis=1).mean() * 1000),
                   gain_vs_near=float(e[g] / e[near].max()), mimic_best=float(mim[g]), mimic_max=float(mim.max()),
                   share_top=float(lam[0] / lam.sum()))
        print(json.dumps(out), flush=True)

# ---------- M2 ----------------------------------------------------------------------------------------------
for Q in (2, 3):
    for r in (1.0, 0.8, 0.3):
        for rep in range(30):
            seed = 820000 + 1000 * (10 * Q + int(r * 10)) + rep
            rng = np.random.default_rng(seed)
            idx, data, eps, Tn = S.simulate(Q, r, 1000.0, rng)
            pos = pos6[idx]
            f = mo.Fit(data, eps, Tn); q = Q - 1
            res = {}
            for name, fn in (('AP', lambda: f.ap(q)), ('AP6', lambda: S.ap_restarts(f, q, 6, np.random.default_rng(seed + 9))),
                             ('ESnp+1', lambda: f.es_fixed(q, q + 1)[2]), ('AP_exactQ', lambda: f.ap(Q))):
                Sx = sorted(int(s) for s in fn())
                Dm = np.linalg.norm(pos7[Sx][:, None] - pos[None], axis=2).min(1) * 1000
                res[name] = dict(prec10=mo.score(Sx, pos, 0.010)['precision'], dist=float(Dm.mean()),
                                 expl=f.prob.explained(Sx))
            print(json.dumps(dict(part='M2', mod=mod, Q=Q, r=r, rep=rep, seed=seed, k=f.prob.k, res=res)), flush=True)
