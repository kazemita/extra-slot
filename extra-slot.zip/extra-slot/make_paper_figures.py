"""Figures 1-3 of the paper, from the raw results in results/ -> figures/ (PDF, PNG, TIFF)."""
import json, glob, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.abspath(__file__))
H = os.path.join(ROOT, 'results', '')
OUT = os.path.join(ROOT, 'figures', '')
plt.rcParams.update({'font.family': 'Liberation Sans', 'font.size': 7.5, 'axes.linewidth': 0.6,
                     'axes.edgecolor': '#52514e', 'xtick.color': '#52514e', 'ytick.color': '#52514e',
                     'axes.labelcolor': '#0b0b0b', 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
                     'xtick.major.size': 2.5, 'ytick.major.size': 2.5, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
BLUE, ORANGE, GRAY, INK, MUTED, GRID = '#2a78d6', '#eb6834', '#8a8984', '#0b0b0b', '#52514e', '#e4e3df'
load = lambda p: [json.loads(l) for f in sorted(glob.glob(H + p)) for l in open(f) if l.strip()]


def boot(d, n=4000, seed=0):
    d = np.asarray(d, float); rng = np.random.default_rng(seed)
    m = d[rng.integers(0, len(d), (n, len(d)))].mean(1)
    return d.mean(), np.percentile(m, 2.5), np.percentile(m, 97.5)


def clean(ax, grid_axis='y'):
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, lw=0.6); ax.set_axisbelow(True)


def save(fig, name):
    for ext, kw in (('pdf', {}), ('png', {'dpi': 300}), ('tif', {'dpi': 600, 'pil_kwargs': {'compression': 'tiff_lzw'}})):
        fig.savefig(OUT + f'{name}.{ext}', bbox_inches='tight', **kw)


summary = {}
# ---------------- Figure 1: mechanism, MEG vs EEG -------------------------------------------------------
M = {m: [json.loads(l) for l in open(H + f'mech_{m}.txt')] for m in ('meg', 'eeg')}
bins = ((30, 50), (50, 70), (70, 100), (100, 200))
blab = ['30–50', '50–70', '70–100', '>100']
fig, axs = plt.subplots(1, 2, figsize=(17.4 / 2.54, 6.2 / 2.54), gridspec_kw={'width_ratios': [1.35, 1]})
ax = axs[0]; w = 0.36
summary['fig1a'] = {}
for k, (m, col, lab) in enumerate((('meg', BLUE, 'MEG'), ('eeg', ORANGE, 'EEG'))):
    X = [d for d in M[m] if d['part'] == 'M1' and d['r'] == 1.0]
    sep = np.array([d['sep_mm'] for d in X]); comp = np.array([d['best_dist_mm'] > 10 for d in X])
    rates = [comp[(sep >= a) & (sep < b)].mean() for a, b in bins]
    ns = [int(((sep >= a) & (sep < b)).sum()) for a, b in bins]
    summary['fig1a'][m] = dict(rates=[round(float(x), 3) for x in rates], n=ns, overall=round(float(comp.mean()), 3))
    x = np.arange(4) + (k - 0.5) * (w + 0.03)
    ax.bar(x, rates, width=w, color=col, label=lab, zorder=3)
    for xi, v in zip(x, rates):
        ax.text(xi, v + 0.012, f'{v:.2f}', ha='center', va='bottom', fontsize=6.3, color=MUTED)
ax.set_xticks(np.arange(4)); ax.set_xticklabels(blab)
ax.set_xlabel('Separation of the two sources (mm)'); ax.set_ylabel('Best single location > 10 mm\nfrom both sources (fraction)')
ax.set_ylim(0, 0.72); clean(ax); ax.legend(frameon=False, loc='upper right', handlelength=1.2)
ax.set_title('a   Noise-free one-source fit to two sources (r = 1)', loc='left', fontsize=7.8, color=INK)
ax = axs[1]
summary['fig1b'] = {}
for k, (meth, col, lab) in enumerate((('AP6', GRAY, 'AP, 6 restarts'), ('ESnp+1', BLUE, 'Extra slot'))):
    vals, los, his = [], [], []
    for m in ('meg', 'eeg'):
        X = [d for d in M[m] if d['part'] == 'M2']
        mu, lo, hi = boot([d['res'][meth]['prec10'] for d in X]); vals.append(mu); los.append(mu - lo); his.append(hi - mu)
        summary['fig1b'][f'{m}_{meth}'] = [round(mu, 3), round(lo, 3), round(hi, 3), len(X)]
    x = np.arange(2) + (k - 0.5) * (w + 0.03)
    ax.bar(x, vals, width=w, color=col, label=lab, zorder=3)
    ax.errorbar(x, vals, yerr=[los, his], fmt='none', ecolor=INK, elinewidth=0.7, capsize=1.8, zorder=4)
    for xi, v in zip(x, vals):
        ax.text(xi, 0.04, f'{v:.2f}', ha='center', va='bottom', fontsize=6.3, color='white', fontweight='bold', zorder=5)
ax.set_xticks([0, 1]); ax.set_xticklabels(['MEG', 'EEG']); ax.set_ylim(0, 1.32); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_ylabel('Precision at 10 mm'); clean(ax)
ax.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, 1.02), ncol=2, handlelength=1.2, columnspacing=1)
ax.set_title('b   Full pipeline, SNR = 1000, Q − 1 slots', loc='left', fontsize=7.8, color=INK)
fig.tight_layout(w_pad=2.2)
save(fig, 'Figure1'); plt.close(fig)

# ---------------- Figure 2: forest plot of all pre-registered tests -------------------------------------
TESTS = [('MEG, sample subject, real background', 'hy[0-9].txt', 'valid'),
         ('EEG, sample subject, real background', 'ee[0-9].txt', 'valid'),
         ('EEG, sample subject, head-model error', 'hm[0-9].txt', 'valid'),
         ('EEG, 30 ch, template head (SNR 0.5/2)', 'e2a[0-9].txt', 'invalid'),
         ('EEG, 30 ch, template head (SNR 2/8)', 'e2b[0-9].txt', 'invalid'),
         ('EEG, 70-ch lead field, simulated background', 'lf[0-9].txt', 'valid'),
         ('EEG, 64-ch lead field, real background', 'lr[0-9].txt', 'valid')]
fig, ax = plt.subplots(figsize=(17.4 / 2.54, 6.0 / 2.54))
fig.subplots_adjust(left=0.33, right=0.64, bottom=0.17, top=0.9)
summary['fig2'] = {}
for i, (lab, pat, val) in enumerate(TESTS):
    R = load(pat)
    d = [r['res']['ESnp+1']['prec10'] - r['res']['AP6']['prec10'] for r in R]
    mu, lo, hi = boot(d)
    v = np.mean([r['res']['AP_exactQ']['prec15'] for r in R])
    dec = 'withheld (invalid)' if v < 0.60 else ('GO' if mu >= 0.10 and lo > 0 else 'MODEST' if lo > 0 else 'NO-GO')
    summary['fig2'][lab] = dict(n=len(R), mean=round(mu, 3), lo=round(lo, 3), hi=round(hi, 3), validity=round(float(v), 3), decision=dec)
    y = len(TESTS) - 1 - i
    col = BLUE if val == 'valid' else GRAY
    ax.plot([lo, hi], [y, y], color=col, lw=1.6, solid_capstyle='round', zorder=3)
    ax.plot(mu, y, 'o', ms=5.2, mfc=col if val == 'valid' else 'white', mec=col, mew=1.3, zorder=4)
    tr = ax.get_yaxis_transform()
    ax.text(1.04, y, f'{mu:+.3f} [{lo:+.3f}, {hi:+.3f}]', va='center', ha='left', fontsize=6.6, color=INK, transform=tr)
    ax.text(1.62, y, dec, va='center', ha='left', fontsize=6.6, color=INK if val == 'valid' else MUTED, transform=tr)
ax.axvline(0, color=MUTED, lw=0.8, zorder=2); ax.axvline(0.10, color=MUTED, lw=0.6, ls=(0, (3, 2)), zorder=2)
ax.text(0.104, len(TESTS) - 0.35, 'GO threshold (0.10)', ha='left', va='bottom', fontsize=6.3, color=MUTED)
ax.set_yticks(range(len(TESTS))); ax.set_yticklabels([t[0] for t in TESTS][::-1])
ax.set_xlim(-0.06, 0.25); ax.set_ylim(-0.6, len(TESTS) - 0.1)
ax.set_xlabel('Extra slot − AP6, precision at 10 mm')
clean(ax, 'x'); ax.grid(False); ax.spines['left'].set_visible(False); ax.tick_params(axis='y', length=0)
tr = ax.get_yaxis_transform()
ax.text(1.04, len(TESTS) - 0.35, 'Difference [95% CI]', ha='left', va='bottom', fontsize=6.6, color=MUTED, fontweight='bold', transform=tr)
ax.text(1.62, len(TESTS) - 0.35, 'Decision', ha='left', va='bottom', fontsize=6.6, color=MUTED, fontweight='bold', transform=tr)
save(fig, 'Figure2'); plt.close(fig)

# ---------------- Figure 3: gain by number of active sources, small multiples ---------------------------
PAN = [('MEG\nsample subject', 'hy[0-9].txt'), ('EEG\nsample subject', 'ee[0-9].txt'),
       ('EEG\nhead-model error', 'hm[0-9].txt'), ('EEG, 70-ch lead field\nsimulated background', 'lf[0-9].txt'),
       ('EEG, 64-ch lead field\nreal background', 'lr[0-9].txt')]
fig, axs = plt.subplots(1, 5, figsize=(17.4 / 2.54, 5.4 / 2.54), sharey=True)
summary['fig3'] = {}
for ax, (lab, pat) in zip(axs, PAN):
    R = load(pat); summary['fig3'][lab] = {}
    for Q in (2, 3, 4):
        d = [r['res']['ESnp+1']['prec10'] - r['res']['AP6']['prec10'] for r in R if r['Q'] == Q]
        mu, lo, hi = boot(d)
        summary['fig3'][lab][Q] = [round(mu, 3), round(lo, 3), round(hi, 3)]
        ax.plot([Q, Q], [lo, hi], color=BLUE, lw=1.6, solid_capstyle='round', zorder=3)
        ax.plot(Q, mu, 'o', ms=5, color=BLUE, mec='white', mew=1.0, zorder=4)
    ax.axhline(0, color=MUTED, lw=0.8, zorder=2)
    ax.set_xticks([2, 3, 4]); ax.set_xlim(1.5, 4.5); clean(ax)
    ax.set_title(lab, fontsize=7, color=INK)
    ax.set_xlabel('Active sources Q')
axs[0].set_ylabel('Extra slot − AP6\n(precision at 10 mm)')
axs[0].set_ylim(-0.12, 0.45)
fig.tight_layout(w_pad=0.6)
save(fig, 'Figure3'); plt.close(fig)
json.dump(summary, open(OUT + 'figure_summary.json', 'w'), indent=1)
print(json.dumps(summary, indent=1))
