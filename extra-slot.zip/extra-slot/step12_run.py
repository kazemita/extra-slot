"""Part A (decisive) and Part B (baselines + runtime) runner, PREREGISTRATION_STEP12.md.

usage: python3 step12_run.py SETTING PART NPARTS NREP SNR1,SNR2 SEED0
       SETTING in {eeg, lf70, hme};  python3 step12_run.py hme-diag
"""
import sys, json, time
import numpy as np
import baselines as B

setting = sys.argv[1]
if setting in ('hme', 'hme-diag'):
    import hme_run as S
    simulate = lambda Q, rho, snr, rng, rep: S.simulate_k(rep % 6, Q, rho, snr, rng)
    TRUE = S.pos6
elif setting == 'eeg':
    import eeg_run as S
    simulate = lambda Q, rho, snr, rng, rep: S.simulate(Q, rho, snr, rng)
    TRUE = S.pos6
elif setting == 'lf64r':                                # PREREGISTRATION_LF64REAL.md (mapping via LF64_MAP)
    import lf64r_run as S
    simulate = lambda Q, rho, snr, rng, rep: S.simulate(Q, rho, snr, rng)
    TRUE = S.POS
elif setting == 'lf70':
    import lf70_run as S
    simulate = lambda Q, rho, snr, rng, rep: S.simulate(Q, rho, snr, rng)
    TRUE = S.POS
mo = S.mo
GRIDPOS = mo.GRID

if setting == 'hme-diag':                            # correct-count diagnostic on non-test seeds (SNR rule)
    p15 = {0.5: [], 2.0: []}
    for i in range(36):
        snr = (0.5, 2.0)[i % 2]; Q = 2 + (i // 2) % 3; rho = (1.0, 0.8, 0.3)[(i // 6) % 3]
        rng = np.random.default_rng(593000 + i)
        idx, data, eps, Tn = simulate(Q, rho, snr, rng, i)
        f = mo.Fit(data, eps, Tn)
        p15[snr].append(mo.score(f.ap(Q), TRUE[idx], 0.015)['precision'])
    pooled = np.mean(p15[0.5] + p15[2.0])
    print('correct-count precision@15: SNR 0.5 %.2f, SNR 2 %.2f, pooled %.2f -> use SNR %s'
          % (np.mean(p15[0.5]), np.mean(p15[2.0]), pooled, '{0.5, 2}' if pooled >= 0.70 else '{2, 8}'))
    sys.exit()

part, nparts, nrep = int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
snrs = tuple(float(x) for x in sys.argv[5].split(','))
seed0 = int(sys.argv[6])
cells = [(Q, rho, snr) for Q in (2, 3, 4) for rho in (1.0, 0.8, 0.3) for snr in snrs]
jobs = [(c, k) for c in cells for k in range(nrep)][part::nparts]
for (Q, rho, snr), rep in jobs:
    seed = seed0 + 1000 * cells.index((Q, rho, snr)) + rep
    rng = np.random.default_rng(seed)
    idx, data, eps, Tn = simulate(Q, rho, snr, rng, rep)
    pos = TRUE[idx]
    t0 = time.perf_counter(); f = mo.Fit(data, eps, Tn); prep = time.perf_counter() - t0
    r2 = np.random.default_rng(seed + 9); q = Q - 1
    out = dict(setting=setting if setting != 'lf64r' else 'lf64r:' + S.MAP, Q=Q, rho=rho, snr=snr, rep=rep, seed=seed, k=f.prob.k, prep_sec=prep, res={})

    def rec(name, fn):
        t = time.perf_counter(); S_ = sorted(int(s) for s in fn()); dt = time.perf_counter() - t
        s10, s15 = mo.score(S_, pos, 0.010), mo.score(S_, pos, 0.015)
        Dm = np.linalg.norm(GRIDPOS[S_][:, None] - pos[None], axis=2).min(1) * 1000
        out['res'][name] = dict(found=S_, prec10=s10['precision'], rec10=s10['recall'], prec15=s15['precision'],
                                rec15=s15['recall'], dist=float(Dm.mean()), expl=f.prob.explained(S_), sec=dt)
    rec('AP', lambda: f.ap(q))
    rec('AP6', lambda: S.ap_restarts(f, q, 6, r2))
    rec('ESnp+1', lambda: f.es_fixed(q, q + 1)[2])
    rec('ESnp+2', lambda: f.es_fixed(q, q + 2)[2])
    rec('ESpol+1', lambda: f.es_fixed(q, q + 1)[0])
    rec('TRAP', lambda: B.trap_music(f, q))
    rec('LCMV', lambda: B.lcmv_peaks(f, q, GRIDPOS))
    rec('AP_exactQ', lambda: f.ap(Q))
    print(json.dumps(out), flush=True)
